-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
--
-- Host: localhost    Database: dnet_ad2025
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `details` text,
  `url` varchar(255) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `duration` varchar(50) DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES (1,'ME','Muharrom Eka','LOGIN','Login','proseslogin.php','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','-','2026-01-24 22:21:38'),(2,'ME','Muharrom Eka','LOGIN','Login','proseslogin.php','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','-','2026-01-25 15:11:45'),(3,'ME','Muharrom Eka','LOGIN','Login','verify_2fa.php','192.168.1.83','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','-','2026-01-25 16:56:47'),(4,'ME','Muharrom Eka','LOGIN','Login','proseslogin.php','192.168.1.83','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','-','2026-01-25 16:57:51'),(5,'ME','Muharrom Eka','DELETE','Menghapus Data Prestasi Atas Nama: ABDUR WAFI ALI','prestasifix.php?&aksi=hapus&urut=14&is_ajax=true','192.168.1.83','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','-','2026-01-25 17:49:56'),(6,'ME','Muharrom Eka','LOGIN','Login','proseslogin.php','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','-','2026-01-25 19:20:00');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbset`
--

DROP TABLE IF EXISTS `dbset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dbset` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dbname` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tahun` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `aktif` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbset`
--

LOCK TABLES `dbset` WRITE;
/*!40000 ALTER TABLE `dbset` DISABLE KEYS */;
INSERT INTO `dbset` VALUES (1,'dnet_ad','2024','0'),(2,'dnet_ad2025','2025','1');
/*!40000 ALTER TABLE `dbset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legalisir`
--

DROP TABLE IF EXISTS `legalisir`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `legalisir` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_surat` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tgl_dokumen` varchar(200) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `ditujukan` varchar(300) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `perihal` varchar(200) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `pembuat` varchar(25) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `pdf` varchar(200) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legalisir`
--

LOCK TABLES `legalisir` WRITE;
/*!40000 ALTER TABLE `legalisir` DISABLE KEYS */;
INSERT INTO `legalisir` VALUES (1,'test','2026-01-25','test','test','test','2025/20260125_test_test_piagam_3.pdf');
/*!40000 ALTER TABLE `legalisir` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `ip_address` varchar(45) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `attempts` int NOT NULL,
  `last_attempt_time` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ip` (`ip_address`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migration_test`
--

DROP TABLE IF EXISTS `migration_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migration_test` (
  `id` int NOT NULL AUTO_INCREMENT,
  `test_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration_test`
--

LOCK TABLES `migration_test` WRITE;
/*!40000 ALTER TABLE `migration_test` DISABLE KEYS */;
INSERT INTO `migration_test` VALUES (1,'Migration System working!');
/*!40000 ALTER TABLE `migration_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `executed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestasi`
--

DROP TABLE IF EXISTS `prestasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prestasi` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pd` varchar(99) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kelas` varchar(25) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `prestasisiswa` varchar(99) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `jenisprestasi` varchar(99) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tgl_kegiatan` varchar(80) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tingkat` varchar(99) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `lokasi` varchar(88) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `pdf` varchar(200) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestasi`
--

LOCK TABLES `prestasi` WRITE;
/*!40000 ALTER TABLE `prestasi` DISABLE KEYS */;
/*!40000 ALTER TABLE `prestasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profils`
--

DROP TABLE IF EXISTS `profils`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profils` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nsekolah` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `npsn` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `alamat` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kecamatan` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kelurahan` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `provinsi` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kabupaten` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kodepos` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `no_telp` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `website` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `nipkasudin` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `nrkkasudin` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `kasudin` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kepsek` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '-',
  `nipkepsek` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '-',
  `nrkkepsek` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `pengawas` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '-',
  `nippengawas` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '-',
  `nrkpengawas` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kasi` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs DEFAULT '-',
  `nipkasi` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '-',
  `nrkkasi` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `ktu` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `nipktu` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `nrkktu` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `logo_sekolah` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT 'logo_default.png',
  `background_login` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT 'bg_default.jpg',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profils`
--

LOCK TABLES `profils` WRITE;
/*!40000 ALTER TABLE `profils` DISABLE KEYS */;
INSERT INTO `profils` VALUES (1,'SMP Negeri 171','20103617','Jl. SMP 171 No.18','Ciracas','Rambutan','DKI JAKARTA','Jakarta Timur','13740','0218414989','mail@smpn171.sch.id','smpn171.sch.id','','','HORALE TUA','SUHARTO, S.Pd','-','','Drs. Baharuddin Dalimunthe.M.M','-','-','Tuti Agiawati','-','','SYARIFAH MASNAENI, S.Pd','','','logo_sekolah_1766127900.png','bg_default.jpg');
/*!40000 ALTER TABLE `profils` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `runtxt`
--

DROP TABLE IF EXISTS `runtxt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `runtxt` (
  `id` int NOT NULL,
  `txt` varchar(250) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `runtxt`
--

LOCK TABLES `runtxt` WRITE;
/*!40000 ALTER TABLE `runtxt` DISABLE KEYS */;
/*!40000 ALTER TABLE `runtxt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server`
--

DROP TABLE IF EXISTS `server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `server` (
  `id` int NOT NULL,
  `weboff` varchar(2) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `log_server` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server`
--

LOCK TABLES `server` WRITE;
/*!40000 ALTER TABLE `server` DISABLE KEYS */;
/*!40000 ALTER TABLE `server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `siswa`
--

DROP TABLE IF EXISTS `siswa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `siswa` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pd` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `jk` varchar(5) COLLATE latin1_general_ci NOT NULL,
  `nis` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kelas` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `photo` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=834 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `siswa`
--

LOCK TABLES `siswa` WRITE;
/*!40000 ALTER TABLE `siswa` DISABLE KEYS */;
INSERT INTO `siswa` VALUES (1,'ADAM KANA BAWI*','','9992','71',''),(2,'ADERA LUQYANA KHALDA','','9993','71',''),(3,'AIRA SA`BANIYAH','','9994','71',''),(4,'AISHA AINUN MAHYA','','9995','71',''),(5,'ALFIAN PURNOMO SIDIK','','9996','71',''),(6,'ALYA NURHADISTY','','9997','71',''),(7,'ALZEMA HARUM RAMADHAN','','9998','71',''),(8,'ANDINI ARUNINGTYAS','','9999','71',''),(9,'BAGAS BIL FAQIH','','10000','71',''),(10,'BINTANG LANGIT CAESAR MMBUMI','','10001','71',''),(11,'BINTANG OZIL VALERIAN','','10002','71',''),(12,'CALLYSTA KEYSHA NOVIANTI','','10003','71',''),(13,'DEANA NAZWA KUSUMA','','10004','71',''),(14,'DHIYA FITRI SALSABILA ZAINIS','','10005','71',''),(15,'FADLI LUTFI HIBATULLAH AL SUNNI','','10006','71',''),(16,'GALIH RAMDANI','','10007','71',''),(17,'GHINA NUR ALAYYA','','10008','71',''),(18,'KANAYA LUTFHI SHALSYA BILA','','10009','71',''),(19,'KHAIRANI LATIFAH AINI','','10010','71',''),(20,'MARSYA AULIA','','10011','71',''),(21,'MUHAMAD ZULKARNAIN*','','10013','71',''),(22,'MUHAMMAD FAIZ HABIBI','','10014','71',''),(23,'MUHAMMAD FARIQ AKHDAN','','10015','71',''),(24,'MUHAMMAD HAIKAL RAMADHAN','','10016','71',''),(25,'MUHAMMAD LUTHFI ZAIDAN','','10017','71',''),(26,'MUHAMMAD RAYN AL NADIM','','10247','71',''),(27,'MUHAMMAD RIFAN MAULANA','','10018','71',''),(28,'MUHAMMAD RUSDI THAMRIN','','10019','71',''),(29,'MUHAMMAD ZEIN ALDIANSYAH','','10020','71',''),(30,'NADHIRA PERMATASARI','','10021','71',''),(31,'NASHITA PUTRI RAMADHANI','','10022','71',''),(32,'NAUFAL HABIBI','','10023','71',''),(33,'NAYARA KIRANA ADIRAHAYU','','10024','71',''),(34,'PATIH PUTRA DESTIAN','','10025','71',''),(35,'RAFIF JUNANDA','','10026','71',''),(36,'YASMINE SYABILA PUTRI','','10027','71',''),(37,'ABHINAYA RAFFATA ADHAZA','','10028','72',''),(38,'AHMAD HUSEIN','','10029','72',''),(39,'ALIYYA LATHIFAH','','10030','72',''),(40,'AKASYAH ANASTASYA','','10248','72',''),(41,'ANZIYAA ZALIKA','','10031','72',''),(42,'AQIILA DESVIANA','','10032','72',''),(43,'ARFA RAFI AZKHA PUTRA JAWAK','','10033','72',''),(44,'AURELIA ANGGRAENI','','10034','72',''),(45,'FAAIQ AL AZZAAM','','10035','72',''),(46,'FADIL RIYADI AL HAJJ','','10036','72',''),(47,'FAJAR MANUNGGALING FADILLAH','','10037','72',''),(48,'FARZAN AHZA ARGANI','','10038','72',''),(49,'FERNANDA MUTIA KASIH','','10039','72',''),(50,'GHASAWAN RAUSAN FIKRI','','10040','72',''),(51,'INDRA AKBAR MUHROBI','','10041','72',''),(52,'JANEETA DHIA SYARAFANA FERDHA','','10042','72',''),(53,'JAUZAA FIRDAUSI','','10043','72',''),(54,'LOVELY ZAAHIRA VIOLETHA','','10044','72',''),(55,'MUHAMMAD NASUHA PRASETYA','','10045','72',''),(56,'MUHAMMAD NAUFAL SYAFIQ','','10046','72',''),(57,'MUHAMAD RAFFA KURNIAWAN','','10249','72',''),(58,'MUHAMMAD RASYA FADILLAH','','10047','72',''),(59,'MUHAMMAD RIDHO','','10048','72',''),(60,'MUHAMMAD RIZKI AKHYAR DALIMUNTE','','10049','72',''),(61,'MUTIARA RENGGANIS KURNIAWAN ROY','','10050','72',''),(62,'NADIA PUTRI ZHAFIRA MUSLIMAH','','10051','72',''),(63,'NAELATUR ROJA','','10052','72',''),(64,'QOTRUNNADA','','10053','72',''),(65,'RAFFI AHMAD SOFYAN','','10055','72',''),(66,'RANGGA SAPUTRA*','','10056','72',''),(67,'RIDHWAN AULIA','','10057','72',''),(68,'RIFQI ABDILLAH PRAYITNO','','10058','72',''),(69,'STEPHANNY FREDERICA','','10059','72',''),(70,'SYIFA KHOIRUNNISA','','10060','72',''),(71,'WURYANTI','','10061','72',''),(72,'ZAHRAN RAMADHAN','','10062','72',''),(73,'ABUZAR','','10063','73',''),(74,'ADILA ZIADATUL HUSNA','','10064','73',''),(75,'ADLIANSYAH','','9768','73',''),(76,'AIDAN IBRAHIM MANAN','','10065','73',''),(77,'AJENG FITRI HANDAYANI','','10066','73',''),(78,'ALIFAH FARAH DZAKIYAH BACHTIAR','','10067','73',''),(79,'ALVIS GAVRILA SIREGAR','','10068','73',''),(80,'ANANDA ABRAR MU`IZZ','','10069','73',''),(81,'ANNISA MAULIDA','','10070','73',''),(82,'ARKAN FATURRACHMAN','','10071','73',''),(83,'DHIA SILMI ATIYAH','','10072','73',''),(84,'FAHMI RASYIQ AISY','','10073','73',''),(85,'FAINE ADIRATNA MARTIN','','10074','73',''),(86,'FAKHRI HIBATULLOH','','10075','73',''),(87,'FIKRI RADITYA AL FARIZI','','10076','73',''),(88,'FULVYA TALITHA NURSYIFA','','10077','73',''),(89,'HIROSHI MARSIMA','','10078','73',''),(90,'KENZIE PASHA SEPTIANZA','','10079','73',''),(91,'MIKHAYLA RAJWA AZALIA LONDORAN','','10080','73',''),(92,'MUHAMAD BILAL ALFIAN MAHMUD','','10081','73',''),(93,'MUHAMMAD DAFVIAN ALVATAR','','10082','73',''),(94,'MUHAMMAD FADLAN KHAIRUL ANAM','','10083','73',''),(95,'MUHAMMAD NEVAN SAVAPUTRA MUHAYYAR','','10084','73',''),(96,'MUHAMMAD RADITYA PRATAMA','','10085','73',''),(97,'NABILA UMMUHANI*','','10087','73',''),(98,'NISA LATI MUSLIMAH','','10088','73',''),(99,'QATRINNADA KHALISA','','10089','73',''),(100,'RAFFA GHARIN ARCADIA','','10090','73',''),(101,'RAHMAT DERMAWAN*','','10091','73',''),(102,'SABRINA NOVIANTI','','10092','73',''),(103,'TANISHA AURELIA KHALFANY','','10093','73',''),(104,'WINOLA DWI PRASETYA','','10094','73',''),(105,'ZAHIRA SAFITRI','','10095','73',''),(106,'ZHIVANA MEILOVA','','10096','73',''),(107,'ZIVARA RIZKA ALTHAFUNISSA','','10097','73',''),(108,'AHMAD FAUZHI','','10098','74',''),(109,'ALENA CHELSEA APRILYAN','','10099','74',''),(110,'ALVI DAMAYANTY','','10100','74',''),(111,'ARYA BINTANG MAHARDHIKA','','10101','74',''),(112,'AULIA NAZHIFAH RIZLIN','','10102','74',''),(113,'AZKA IBNU FIQI','','10103','74',''),(114,'AZRA YUSUF ALBANI-RAY','','10104','74',''),(115,'BAIHAKI ULHAQ KAIZAN','','10105','74',''),(116,'CITRA SANIA','','10106','74',''),(117,'DAANISH GULWANI FAIZ','','10107','74',''),(118,'DYHAN OKAVIANO*','','10108','74',''),(119,'FAZA KHAIRINA DIRGANTARA','','10109','74',''),(120,'GALANG CAKRA GUNAWAN','','10110','74',''),(121,'IBRAHIM RIZKI AIDIL AKBAR','','10111','74',''),(122,'KANAYA APRILIA','','10112','74',''),(123,'MOHAMMAD FABIAN ALVARO','','10113','74',''),(124,'MUHAMMAD ANUGRAH ALFAREZY','','10114','74',''),(125,'MUHAMMAD HAMZAH MAULANA','','10115','74',''),(126,'MUHAMMAD SULTAN HAYDIR ALI','','10116','74',''),(127,'NAYLA NUR FITRIAH','','10117','74',''),(128,'NHAURA FATHIYYAH ISKANDAR','','10118','74',''),(129,'NOVA INDAH SYAFITRI','','10119','74',''),(130,'NURKHOLIS SHAFWAN BARDIANTO','','10120','74',''),(131,'RAFA NUHA NAZWA','','10121','74',''),(132,'RAIHANNA DZAHIRA','','10122','74',''),(133,'RAKHA ADITYA RASHIF','','10123','74',''),(134,'REAYLITA NUR AZHARA','','10124','74',''),(135,'RESTU ADITIYA ANDHANI','','10125','74',''),(136,'REZKY NAZRIL ILHAM','','10126','74',''),(137,'ROBIE AHMADIN ZIDANE','','10127','74',''),(138,'ROSNAULI HARAHAP','','10128','74',''),(139,'SAKINA SETIAWAN','','10129','74',''),(140,'SYAKILA SYAFIUL ILMI','','10250','74',''),(141,'SAMSUL IMAM GUNAWAN','','10130','74',''),(142,'TIFFANY AURELIA','','10131','74',''),(143,'WELLNES HUMAIRA GHASSANI','','10132','74',''),(144,'ADINDA PUTRI ASTUTI','','10133','75',''),(145,'AGUNG AGUSTIAN MAULANA ADIYANSA','','10134','75',''),(146,'ALWAN SATRIA PUTRA','','10135','75',''),(147,'ALYAA RINJANI','','10136','75',''),(148,'AQUINNA GHANIA WICAKSONO','','10137','75',''),(149,'AREVA ANASTASYA','','10138','75',''),(150,'BUNGA KEYLA FITRIAWAN','','10139','75',''),(151,'CHAERUL SUGIARTO','','10140','75',''),(152,'DAREL DYRA DYAKSA','','10141','75',''),(153,'FARRELVINO JULIANSYAH','','10142','75',''),(154,'FAYRUZ ZAKI HARDIAN','','10143','75',''),(155,'FEBRYANA PUTRI AQILAH','','10144','75',''),(156,'FITRI MULYANINGSIH','','10145','75',''),(157,'GUNTUR ALHAADY','','10146','75',''),(158,'HAFIFAH ANDINY NUR MAYLA','','10147','75',''),(159,'HERNAWAN VICKY FAUZI','','10148','75',''),(160,'KANAYA PUTRI RAMDANI','','10149','75',''),(161,'KEYSHA TRI MULYANI','','10150','75',''),(162,'LONA AZHIMU','','10151','75',''),(163,'MELIA ASHYABELLA','','10152','75',''),(164,'MUHAMMAD ALTHAF NUR ADIA','','10153','75',''),(165,'MUHAMMAD DATUL KAHFI RASIDIN','','10154','75',''),(166,'MUHAMMAD FADLI AKMAL','','10155','75',''),(167,'MUHAMMAD NAUFAL AZZAM','','10156','75',''),(168,'MUHAMMAD RIOS HAIRIYAWAN','','10157','75',''),(169,'MUHAMMAD ZIHNI KAROMI','','10158','75',''),(170,'NATHANIA NUR AFIIFAH HARTONO','','10159','75',''),(171,'NUR AZIZAH GULTOM','','10160','75',''),(172,'RABBANI BISMA ABIMANYU','','10161','75',''),(173,'RADITYA KAFI AKBAR PRATAMA','','10162','75',''),(174,'RAHMAT HIDAYAT','','10163','75',''),(175,'RINA PUTRIANA','','10164','75',''),(176,'SATRIA TAMA RAMADHAN','','10165','75',''),(177,'SITI FADILLAH','','10166','75',''),(178,'WAHID KHAIRUL AZZAM','','10167','75',''),(179,'WARDANA BAHARI','','10168','75',''),(180,'ADINDA KHAIRUNISA','','10169','76',''),(181,'AKILA ANINDITA','','10170','76',''),(182,'ALINDA FADIAH ZIHNI','','10171','76',''),(183,'ARTHUR JONATHAN PASARIBU','','10172','76',''),(184,'AZRIL AFRIZAL','','10173','76',''),(185,'CAHYA AUFA ATIQAH','','10174','76',''),(186,'CALVIN BASTIAN RIENOS SIDABALOK','','10175','76',''),(187,'DEVIAN DZIKRI ARRAYAN','','10176','76',''),(188,'DINAH SETYA HUSNA','','10177','76',''),(189,'DIVA KHAIRUNNISA','','10178','76',''),(190,'FAREL HARTONO','','10179','76',''),(191,'GRISELDA AILSA SEBAYANG','','10180','76',''),(192,'HANIF AL ADLUL LATIEF','','10181','76',''),(193,'JEREMIA BARITA TULUS SIHOTANG','','10182','76',''),(194,'KAREN STEPHANI','','10183','76',''),(195,'KHALISHA SALSABILA FATHURRAHMAN','','10184','76',''),(196,'LALU RIZKY ZAIDAN','','10185','76',''),(197,'LISA APRILLIA MUSLIMAH','','10186','76',''),(198,'MEISYA MAHARANI','','10187','76',''),(199,'MELVYN HIEGO ANRESI LIAN','','10188','76',''),(200,'MUHAMMAD AKBAR FAIS RIFA`I','','10189','76',''),(201,'MUHAMMAD BIMA AZHAR','','10190','76',''),(202,'MUHAMMAD FARHAN ARDIANSYAH','','10251','76',''),(203,'MUHAMMAD JAWWAD','','10191','76',''),(204,'MUHAMMAD RAFIQ ABDULLAH','','10192','76',''),(205,'MUHAMMAD RAKHA RAJENDRA','','10193','76',''),(206,'MUHAMMAD RIZQI AZZAHQRI','','10194','76',''),(207,'NADHIRA HARDIANSAH MAULIDA','','10195','76',''),(208,'NATASYA REVINA NAIBAHO','','10196','76',''),(209,'NISYA SYAM PUTRI','','10197','76',''),(210,'PAJRI PRATAMA','','10198','76',''),(211,'RADHA NADA ADRYANA GINTING','','10199','76',''),(212,'RIDWAN FADIL RAHMAN','','10200','76',''),(213,'ROSA OKI SAGITA*','','10201','76',''),(214,'SAMUEL DESHAWN JACOB SIAHAAN','','10202','76',''),(215,'VINNO ARDIANSYAH','','10203','76',''),(216,'ACHMAD ALFARREL QINTHARU','','10204','77',''),(217,'AILSA HUMAIRA MAHARANI','','10205','77',''),(218,'AKHTARIZAL HASAN','','10206','77',''),(219,'ARSYA AMANDA PUTRI','','10207','77',''),(220,'ARUNG NAWAYKA ISKANDAR','','10208','77',''),(221,'AULIA DESCA AFIFAH*','','10209','77',''),(222,'AZZAHRA NUR ASSYIFA','','10210','77',''),(223,'CHRISTOPHER NATHANIEL BALA KELEN','','10211','77',''),(224,'CRISNATAL ALOYSIUS PUTRA SITUMORANG','','10212','77',''),(225,'DAENG ASLAH NABAWIE','','10213','77',''),(226,'FARHAN NABIL ALBUKHORI*','','10214','77',''),(227,'FATTAH LABIB SIDIQ','','10215','77',''),(228,'FAVIAN DEFARO ANGGARA SUTANDI','','10252','77',''),(229,'GRACIELLA KANA SHANATA NAINGGOLAN','','10216','77',''),(230,'HANIFA KAREZMAWATI','','10217','77',''),(231,'HUGO APRILIANO','','10218','77',''),(232,'IMADA LUCAS MANGARAJA DOLOK SARIBU','','10219','77',''),(233,'IVANA DIAS MARISA','','10220','77',''),(234,'JONATHAN NATANAEL','','10221','77',''),(235,'KHALISA RANIA PUTRI','','10222','77',''),(236,'KHANSA SHAKILA ALLYANA','','10223','77',''),(237,'LIVIA SISTA DELVARA','','10224','77',''),(238,'LUCIO BENEDIKTO ALDO KEBE','','10225','77',''),(239,'MELODY ABIGAIL','','10226','77',''),(240,'MUHAMMAD ABU BAKAR','','10227','77',''),(241,'MUHAMMAD AKBAR DERMAWAN','','10228','77',''),(242,'MUHAMMAD RAKHA ASSYRAF','','10230','77',''),(243,'MUHAMMAD RASYA ARIYA','','10231','77',''),(244,'NADYA SARADIVA SYAH','','10232','77',''),(245,'NAZWA ASAELLA FEBRIANTI','','10233','77',''),(246,'PEDRO TOMPI BOREZ HUTASOIT','','10234','77',''),(247,'PUSPA AYUNINGTYAS HAPSARI','','10235','77',''),(248,'RAFISQY HANIFAN PUTRA SUSANTO','','10236','77',''),(249,'RAINA AYU SAPUTRI','','10237','77',''),(250,'WELLY AL-QORNI','','10238','77',''),(251,'ABDUL JALIL HAIDAR ALI','','9767','81',''),(252,'ACHMAD FADLU RAHMAN*','','9907','81',''),(253,'ADINDA MAHARANI','','9697','81',''),(254,'ADITYA CAHAYA PURNAMA PUTRA','','9802','81',''),(255,'ADRIAN EL NINO','','9698','81',''),(256,'ANGGITA APRIYANTI','','9808','81',''),(257,'ANINDITYA MEYCA RAIFA','','9770','81',''),(258,'CHALISAH PUTRI','','9949','81',''),(259,'DENNISH EZRA MAHARDIKA','','9912','81',''),(260,'DINDA ZAZKIA DEWI','','9952','81',''),(261,'FAIRUZ PUTRI KHIRANIA    OSIS','','9916','81',''),(262,'FAIZ FIRDAUS','','9917','81',''),(263,'IRDINA NAURAH PUTRI','','9751','81',''),(264,'JERRICO JEFA ALIF SETYAWAN*','','9885','81',''),(265,'KAFI ZUFAR RADINKA','','9752','81',''),(266,'KAYLA NUR TREE OKTAVIANI','','9753','81',''),(267,'MOHAMMAD RIZQI JUANDA','','9754','81',''),(268,'NAKULA MARNUSYANTO','','9758','81',''),(269,'NINA RISANTI','','9966','81',''),(270,'OVI SILVANA','','9795','81',''),(271,'QUINA ANINDYA DEWI','','9796','81',''),(272,'RADEN NAUFAL AYDIN RAHARJO','','9829','81',''),(273,'RADHITYA PUTRA PERMANA','','9895','81',''),(274,'REYFHAN TRISNA NOERADHITYA','','9899','81',''),(275,'RAFFY APRIANSYAH','','9864','81',''),(276,'RAHENDRA ARIOBARRA','','9797','81',''),(277,'RASYA KEANU ALBARI SYAM','','9866','81',''),(278,'RESKIKA NUR OKTAVIANI','','9867','81',''),(279,'RIZKY MULYA PRATAMA','','9832','81',''),(280,'SADEWA MARNUSYANTO','','9868','81',''),(281,'SASKIA ANANDITA PRATIWI','','9799','81',''),(282,'SAUZAN SYARIFA','','9902','81',''),(283,'SEPTA RAFKY ALWARITSU','','9833','81',''),(284,'SIGIT HERMAWAN','','9800','81',''),(285,'VERA APRILIANI','','9939','81',''),(286,'ZAVIRA KENCANA','','9731','81',''),(287,'AHMAD FADLI','','9873','82',''),(288,'AISYAH AJENG AYU MAHARANI','','9804','82',''),(289,'ALETA CHIKA NUGRAHA','','9875','82',''),(290,'ALIYA NAILATUN NAJWA','','9805','82',''),(291,'ANTAREJA BANYU MAHESWARA','','9946','82',''),(292,'ARKAN NURANDI TAJRIANSYAH','','9989','82',''),(293,'BANYU REZZKA ALVINO','','9739','82',''),(294,'BAYU AGUNG NUGROHO','','9947','82',''),(295,'CAHYA AURELIA SEPTA','','9740','82',''),(296,'DENNIAR FARDIAN WICAHYA SYAHPUTRA','','9911','82',''),(297,'DZAKIYAH HAFIFATUNNISA','','9815','82',''),(298,'EPELLIA FHITRI','','9741','82',''),(299,'FAHREZA ADAM CRISTIANTOMY','','9915','82',''),(300,'FIONA ALYA SAPUTRI','','9848','82',''),(301,'GALANG SETIAWAN','','9918','82',''),(302,'HILDA NOVRIDA','','9990','82',''),(303,'INDHIRA EVRILIA','','9884','82',''),(304,'IRGHI YUAN RAMDHANI','','9713','82',''),(305,'IDAM NURIL MUKHORIM*','','9712','82',''),(306,'IZZAT GILANG CANDRIKA','','9714','82',''),(307,'KAIA SIBYL HABIBAH','','9886','82',''),(308,'KEYRIANA VINO AISYAHRANI','','9715','82',''),(309,'MAULANA MUHAMAD YUSUP*','','9961','82',''),(310,'MUHAMAD B. S. RANGGA*','','9892','82',''),(311,'MUHAMMAD AZHAR FADILLAH','','9857','82',''),(312,'MUHAMMAD AZZAM DAULI','','9987','82',''),(313,'MUHAMMAD RIZKY AQWIYAH','','9964','82',''),(314,'MUHAMMAD FADILLAH JAILANI','','9893','82',''),(315,'NAIA RIZKA SILVIA','','9792','82',''),(316,'NURJIHA SABRINA GHAISANI','','9793','82',''),(317,'QUEENSHA AULIA SYIFA','','9934','82',''),(318,'RAFA AZAM ALFIYAN','','9726','82',''),(319,'RANGGA FAIZ','','9865','82',''),(320,'SYARIFAH ANDHINI HAYOTO','','9801','82',''),(321,'TANIA APRILIA','','9834','82',''),(322,'ABDULLAH IBNU BATUTA','','9696','83',''),(323,'AHMAD ZULFIKAR FADHLY','','9803','83',''),(324,'AIRIL JOHARI','','9733','83',''),(325,'AKHDAN BHADRIKA*','','9874','83',''),(326,'ALKISYAH REWAE','','9734','83',''),(327,'ANDITA PUTRIE MAULINDA','','9806','83',''),(328,'ANDRY TRIANA HIDAYAT DENY SAPUTRA','','9807','83',''),(329,'ARGHYA RAVA AGISTA','','9772','83',''),(330,'ATIKA PUTRI RAHAYU','','9773','83',''),(331,'AUFA FAUZAN RIALDI*','','9841','83',''),(332,'AZIZAH SETIAWAN','','9877','83',''),(333,'DAFFA AGUNG PRAMUDYA','','9951','83',''),(334,'DELLA SYAHRANI','','9706','83',''),(335,'DEVIN AQILA RAFASYAH','','9913','83',''),(336,'FAHRY ANUGRAH KUSUMA','','9817','83',''),(337,'KHOIRUL IRSYAD','','9853','83',''),(338,'LEGITHA AVRILLIA MAHARANI','','9925','83',''),(339,'MEISYA LONA PLARASUKA','','9927','83',''),(340,'MUHAMMAD ANANDA SADIXTA','','9856','83',''),(341,'MUHAMMAD AZRIL ILHAM','','9756','83',''),(342,'MUHAMMAD FHADIL','','9789','83',''),(343,'MUHAMMAD MARFEL ALFIANDINOVA','','9858','83',''),(344,'MUHAMMAD QAISER NASHWAN','','9790','83',''),(345,'NABILA NUR KHOLIFAH','','9757','83',''),(346,'NADZWA APRILLYA','','9859','83',''),(347,'NURFI SYABILLA','','9759','83',''),(348,'QUAIS ALQORNI','','9828','83',''),(349,'RACHEL CORRY RAMADHANI','','9724','83',''),(350,'RADIT SHEMDINATA','','9725','83',''),(351,'RAFA RONALDI','','9968','83',''),(352,'RAISA BALQIS AZZAHRA','','9727','83',''),(353,'RENITA SAFITRI','','10253','83',''),(354,'SYAHWANDA MERBY AZALLA','','9905','83',''),(355,'TIKA CAHAYA NURHIKMAH','','9937','83',''),(356,'TRI MAULIDA HENDRI PUTRI','','9870','83',''),(357,'ZIDNI ROHADATUL `AISY','','9906','83',''),(358,'ALIF FAJAR RAMADHAN','','9699','84',''),(359,'ASRUL SANI AL GHIFARI','','9373','84',''),(360,'ARAMI KUKUH MANGGALA PUTRA','','9771','84',''),(361,'ARIF KURNIA ATMAJA','','9809','84',''),(362,'BARAKA DWI GHANIYYU*','','9775','84',''),(363,'CHAESAR CLEO AL FARIZH','','9948','84',''),(364,'CHAYARA EMBUN NAARACHITA','','9950','84',''),(365,'DERIF HAFIDZ RIZKY','','9878','84',''),(366,'DITA APRIYANA','','9879','84',''),(367,'FAHRI DJAINUDIN','','9953','84',''),(368,'FATHIR ADHI SYAPUTRA','','9846','84',''),(369,'FATIMAH AZZAHRA','','9847','84',''),(370,'FIRDA FARIZA GUNAWAN','','9709','84',''),(371,'GENDIS ALYSIA DARAJAT','','9710','84',''),(372,'HAIDIL KHADAFI','','9749','84',''),(373,'HANA OCTAVIA KHAIRUNNISA','','9750','84',''),(374,'HARUM AZHAAR','','9711','84',''),(375,'IRGI ADITYA PRATAMA','','10254','84',''),(376,'JIDANE ARDIANSYAH SAPUTRA','','9850','84',''),(377,'KYLA AULIA PRASETYO','','9786','84',''),(378,'MOHAMMAD KENZIE PRAYATA','','9787','84',''),(379,'MUHAMMAD AMMAR FADHLY','','9855','84',''),(380,'MUHAMMAD FATHAN AL FALAH','','9788','84',''),(381,'NABILA HILFI ANANDA','','9825','84',''),(382,'NASHITA LAILY ZAHIRA','','9826','84',''),(383,'NOVIANA EKA RAHAYU','','9933','84',''),(384,'RAYFAN RAMADHAN*','','9830','84',''),(385,'REYHAN DIMITREE MAHENDRY','','9728','84',''),(386,'RISYIFA ROSICKY','','9761','84',''),(387,'RIVANO SATRIO NUGROHO','','9935','84',''),(388,'SATRIO ARIF ATHAYA','','9936','84',''),(389,'SHABILA ANGGRAENI','','9903','84',''),(390,'SHAFA FADILLAH GAJA','','9763','84',''),(391,'SHERYL NURYADI','','9730','84',''),(392,'SIFA FAUZIAH','','9904','84',''),(393,'SYARAH MAULIDA','','9764','84',''),(394,'AGVA SHADDAM ALI','','9769','85',''),(395,'AHMAD IBRAHIMOVIC','','9838','85',''),(396,'ALYSA CLAUDIA KUSUMA','','9839','85',''),(397,'AMANDA NUR AZIJAH*','','9840','85',''),(398,'AMZHAR SYAUQI OKKA YULIANSYAH','','9942','85',''),(399,'AURELLIA PUTRI HABSARI','','9738','85',''),(400,'BINTANG ARYASATYA APRILIANTINO','','9704','85',''),(401,'BISHRIL MA`ARIF','','9844','85',''),(402,'CALISTA OIEYVINA NUGROHO','','9705','85',''),(403,'DION LAZUARDI PUTRA','','9707','85',''),(404,'DWI HANDIKA','','9880','85',''),(405,'EVRYELLA ALZENNA DEWI SYAHMITA','','9708','85',''),(406,'FAIZAL LUTFI AL FATAH','','9881','85',''),(407,'FAKHIRA NADHEFA ALTHAFUNNISA','','9743','85',''),(408,'FAKHRI AKMA FADHIL','','9845','85',''),(409,'IZQIEVIDIANA','','9957','85',''),(410,'KAYLA KHAIRINA RASYID','','9958','85',''),(411,'KEISYA FATHIYYAH ADRIANI','','9991','85',''),(412,'KENDRA ALIKHA RAMADHANI','','9784','85',''),(413,'MAURA KHAIRUN NISA','','9888','85',''),(414,'MOCHAMMAD ERFINO HIDAYAT','','9962','85',''),(415,'MUHAMAD FADLI FEBRIANTO','','9963','85',''),(416,'MUHAMMAD AZKA KUMARA ADI','','9929','85',''),(417,'MUHAMMAD FAHMI AL FIQIH*','','9823','85',''),(418,'MUHAMMAD RIZKY','','9894','85',''),(419,'MUTIARA FATHINAH NUR IMAN','','9930','85',''),(420,'NADIN SYAFIRA','','9931','85',''),(421,'NENO MEIRANI','','9932','85',''),(422,'OKATARA RAFAEL ARFAN','','9827','85',''),(423,'QALESYA AZKA NADINE','','9723','85',''),(424,'RAFA ARDIANSYAH','','9967','85',''),(425,'SACHA AULIA ARIASTITA','','9762','85',''),(426,'TANAYA TAMA NUNGKA FALAQI MOJAWI','','9974','85',''),(427,'YUDA RASHA RANATA','','9835','85',''),(428,'YULIANA','','9836','85',''),(429,'ZAIDAN ARBHIE FADILLAH','','9977','85',''),(430,'ADITYA BINTANG PRATAMA','','9908','86',''),(431,'AHMAD HAFIDZ ANNAZILY','','9732','86',''),(432,'ALLYA AIRRAH SYAFA','','9909','86',''),(433,'ANNISA NUR AULIYA','','9735','86',''),(434,'ARINA FAIZA NURADITYA','','9736','86',''),(435,'AZKA NURSALSA','','9774','86',''),(436,'AZZA SYAHARA PUTRI','','9842','86',''),(437,'BERLENS RAFEL WILLYANSYAH','','9910','86',''),(438,'CARISSA NAOMI TAMPUBOLON','','9813','86',''),(439,'DARMA UMAR THALIB','','9776','86',''),(440,'DAVA NOVIANSYAH','','9777','86',''),(441,'ENGGAR HARYO ADIWENO AFANDI','','9778','86',''),(442,'FAIZ ADNAN FAUZI','','9742','86',''),(443,'HARI WISTORO BANGUN','','9988','86',''),(444,'KEYSYA KANZA DEPITA','','9820','86',''),(445,'M. FAHRI','','9717','86',''),(446,'MAHAR AKRAM KHADAFI','','9821','86',''),(447,'MEISY RAYYA PUTRI','','9716','86',''),(448,'MUHAMAD IHSAN','','9822','86',''),(449,'MUHAMAD PRABU RAMADHAN','','9718','86',''),(450,'MUHAMAD TAMIM ALGOZALI','','9854','86',''),(451,'MUHAMMAD AZRIEL PUTRA S','','9755','86',''),(452,'MUHAMMAD RIZKY HAWALLI','','9721','86',''),(453,'NAJMA SHAFA LAILA','','9965','86',''),(454,'NASYA INDIRA PUTRI','','9860','86',''),(455,'NURUL FITRI SEPTIA*','','9794','86',''),(456,'PUTRI ANGGRAINI','','9722','86',''),(457,'RAMADHANI RUSMIN*','','9760','86',''),(458,'RAFFA MAULANA ADHA','','9896','86',''),(459,'RIZKY ADITHYA ANUGRAH','','9900','86',''),(460,'RIZKY ADITIYA','','9798','86',''),(461,'SABRINA','','9901','86',''),(462,'SALSHABILA AZZAHRA MPK','','9972','86',''),(463,'ZALVIN DAHLIAN MAHADANI SITUMORANG','','9766','86',''),(464,'ZIVARA NUWALA PUTRI OSIS','','9837','86',''),(465,'ADILLA MEILANI PUTRI','','9872','87',''),(466,'ANABELLA YUKI AURELIA','','9943','87',''),(467,'ANGEL COSTARYCA PURBA','','9944','87',''),(468,'ANISA PUTRI AGUSTIANTY','','9700','87',''),(469,'AQILLAH NASHITA DWI ARIFIANTI','','9701','87',''),(470,'ARUNI FALAKHA TRI MUMPUNI','','9811','87',''),(471,'ELVIRA SHAFA NAWAWILLA','','9816','87',''),(472,'ESHAN ALTHAF SYABIL','','9779','87',''),(473,'FAIZ DHIA ZHAFAR','','9781','87',''),(474,'FAKHRI UKAIL SANTOSA*','','9744','87',''),(475,'FARIZ ARDIANSYAH','','9745','87',''),(476,'FATHAN FADHILAH','','9882','87',''),(477,'FAUZAN','','9746','87',''),(478,'FELLICIA AIRA MALEEKHA','','9883','87',''),(479,'GILBERT LUMAINDONG NABABAN','','9955','87',''),(480,'GLADYS IVANNA HUTAPEA','','9956','87',''),(481,'HAICEL SEPTIAWAN ABIDIN','','9782','87',''),(482,'HAURA ARDINI','','9783','87',''),(483,'KEYZAN DIRA PRATAMA','','9887','87',''),(484,'MANUELLA KARYN ROSINAULI','','9926','87',''),(485,'MIECHELL ZANETHA SIAHAAN','','9928','87',''),(486,'MOHAMMAD NAUVAL AZ-ZIKRA','','9890','87',''),(487,'MUHAMMAD AZRIEL RAIKA','','9719','87',''),(488,'MUHAMMAD KEISA FEBRIANSYAH MALIK','','9720','87',''),(489,'NURUL FAUZIAH','','9861','87',''),(490,'RADITYA KEYZAN SYAMPUTRA','','9862','87',''),(491,'RAFA HAFIIZI ABIMANYU','','9863','87',''),(492,'RAYHAN RAFA AKBAR','','9970','87',''),(493,'RENO INDRAYANA','','9971','87',''),(494,'SABRINA NAYSA WAHAB*','','9729','87',''),(495,'SAMUEL DAPEACE','','9973','87',''),(496,'SARVINA MAHDA WATTIHELU','','9869','87',''),(497,'VINCENTIUS KRISNA PUTRA','','9976','87',''),(498,'VIONA CITRA SITORUS','','9940','87',''),(499,'YOSEF HAYON HALA NIRON','','9941','87',''),(500,'ANGRENI EVALINA SITOMPUL','','9945','87',''),(501,'AUDIS FEBRIANTI','','9876','87',''),(502,'AZRIEL FEBRI AKBAR','','9702','87',''),(503,'AZZAM BAGUS SYANDANA','','9812','87',''),(504,'BAGAS PRATAMA','','9703','87',''),(505,'DIAN PUTRI PERMATASARI','','9914','87',''),(506,'FAIQ ATHAYA','','9780','87',''),(507,'FERDINAND ARYA RIHI MONE','','9954','87',''),(508,'GALANK RAKHA FIRMANSYAH','','9747','87',''),(509,'GOFUR ALFAYET NUGROHO','','9748','87',''),(510,'HESKIANO RAFAEL HUTAGAOL','','9633','87',''),(511,'ILHAM WIJAYA','','9818','87',''),(512,'IRLAND','','9849','87',''),(513,'JESSYCA BELIA PUTRI','','9919','87',''),(514,'JOAN ABNER MATTHEWTUA TAMBUNAN','','9920','87',''),(515,'JUAN GERRALD MULYANA','','9921','87',''),(516,'JUWITA PUSPITASARI','','9819','87',''),(517,'KALISTA QONITA PUTRI','','9851','87',''),(518,'KANDIKA','','9922','87',''),(519,'KASIH MAGDALENA','','9923','87',''),(520,'KAYLA RINJANI AZZAHRA','','9924','87',''),(521,'KEISHA KAFKA NAFIZA','','9852','87',''),(522,'KIANDRA RALLY MOHUNE','','9785','87',''),(523,'LOUISA PALMIA BREITHY','','9959','87',''),(524,'MARIA DWI TRESIA SINURAT*','','9960','87',''),(525,'MUHAMAD ABDUL LATIF','','9891','87',''),(526,'MUHAMMAD RADHY ALKHALIFFI KURNIAWAN','','9824','87',''),(527,'NADIN QUROTA AINI MAHENDRA','','9791','87',''),(528,'RANGGA PRAKASSA PUTRA CHRISTIAN LENGKONG','','9969','87',''),(529,'RASYA AL RAHMAN','','9897','87',''),(530,'REINA DHIZA ETRI KAYLA','','9898','87',''),(531,'REYHAN PUTRA ANDIKA','','9831','87',''),(532,'TAUHIDA IMROAN SHOLIHA ZULFATAHIYA','','9765','87',''),(533,'TRI AYAMEWATI','','9975','87',''),(534,'VANESA SEPTYASA NURMIATI','','9871','87',''),(535,'ACHMAD FARIZI HIDAYATULLAH','','9404','91',''),(536,'ADITYA PUTRA MARSHELA','','9475','91',''),(537,'ALMIRA AYUDIA','','9619','91',''),(538,'ALVINAZ DENNIS SYAHPUTRA','','9442','91',''),(539,'ALYSHA RAHMADIAH','','9374','91',''),(540,'APPLE AULYA RAMDAN','','9444','91',''),(541,'AQWA BIMO ANDREANTO','','9376','91',''),(542,'ARETHA HASNA DZAKIYA','','9586','91',''),(543,'AULIA INDAH SYAPUTRI SARI','','9517','91',''),(544,'BAJA DJIBRIL MARESTIAN','','9588','91',''),(545,'BUNGA NAURAH MUSTOPA','','9411','91',''),(546,'CANTIKA DWI CAHYANI','','9481','91',''),(547,'DAVINA PUTRI FELICIA','','9628','91',''),(548,'FAIZ DZIBAN NURSYAHBANI','','9520','91',''),(549,'GENTHA BHUWANA PAKSA','','9383','91',''),(550,'HAFRIDA HANIDIYAH','','9665','91',''),(551,'KHALILAH DINDA AZZAHRAH','','9693','91',''),(552,'MIFZAL HAMSYARI AL HAFIZ','','9422','91',''),(553,'MIZNA SELVIRA','','9562','91',''),(554,'MUHAMMAD ARIFIN','','9390','91',''),(555,'MUHAMMAD FADLY','','9457','91',''),(556,'MUHAMMAD RAFIF BAIHAKKI','','9602','91',''),(557,'NADIA HAFIZZHA','','9531','91',''),(558,'NIKEISHA SHIRA THALIA','','9569','91',''),(559,'NURLAILA DIAN SAFIRA','','9499','91',''),(560,'RAFI DARMAWANSYAH','','9431','91',''),(561,'RASYAH BIMA ARYA PUTRA','','9432','91',''),(562,'RENDI AGUSTYAS','','9502','91',''),(563,'SANDY ALAMSYAH','','9435','91',''),(564,'SAPBRINA NUR HALIFAH','','9436','91',''),(565,'SARAH NABILA ATHAYA','','9469','91',''),(566,'SHAFIRA AISYAH SANTOSO','','10246','91',''),(567,'TASYA ANILIA PUTRI','','9505','91',''),(568,'ZEFANYA CHRISTO FRIPAL*','','9509','91',''),(569,'AISYAH ZAHIRA','','9581','92',''),(570,'ANA TASYA','','9477','92',''),(571,'ANDRA LAMANDO','','9584','92',''),(572,'ANINDYA PUTRI NASUTION','','9620','92',''),(573,'AQILA SHAKI','','9656','92',''),(574,'ARUM KUSUMA WARDANY','','9478','92',''),(575,'AZARIA SALSABILA KUSMAYA','','9658','92',''),(576,'DAFFA SYAIRAZY KAMIL','','9412','92',''),(577,'DESWITA MAHARANI KUSUMA','','9413','92',''),(578,'ERJI NIZHAR RASYIDI','','9592','92',''),(579,'EXCEL ALFIANSYAH IRAWAN','','9629','92',''),(580,'FAHRI ANDIKA RAHARJO','','9484','92',''),(581,'HAFIDZ RAFI RAMADHANI','','9451','92',''),(582,'INTAN KUSUMA WARDANI','','10241','92',''),(583,'JULIAN SATRIA ADITYO','','9386','92',''),(584,'KAISA RAIA','','9487','92',''),(585,'MEISYA NATASYA','','9527','92',''),(586,'MUHAMMAD ALIF PUTRA SENTOSA','','9600','92',''),(587,'MUHAMMAD FAUZAN*','','9694','92',''),(588,'MUHAMMAD RAFKA IBRAHIM','','9391','92',''),(589,'MUHAMMAD RIZKY RAMADHAN','','9530','92',''),(590,'MUTIARA LIANA AZURA','','9604','92',''),(591,'NIKITA MECCA KRISNAYADI','','9605','92',''),(592,'NUR HOLILA JULIANTI','','9675','92',''),(593,'NURYADI','','9534','92',''),(594,'RADITYA GUNA SURANTO','','9430','92',''),(595,'RAMA HAIKAL','','9607','92',''),(596,'RIFQI ACHMAD SETIADI','','9466','92',''),(597,'TIARA FATHIMAH HASNA','','9506','92',''),(598,'UMAR KHADAVIE','','9507','92',''),(599,'ZAKARIA FA`IZ','','9544','92',''),(600,'ZARA LINTANG MAJIDAH','','9650','92',''),(601,'ZEMANOVELIN','','9473','92',''),(602,'ABDUR WAFI ALI','','9368','93',''),(603,'ADINATA ARYA NUGRAHA','','9440','93',''),(604,'ADITIA IRWANSYAH*','','9370','93',''),(605,'ALVINO YOGA PRATAMA','','9476','93',''),(606,'AMELIA KARTIKA','','9433','93',''),(607,'ARFAN HIDAYATULLAH','','9408','93',''),(608,'AYESHA MAYSHARLA','','9623','93',''),(609,'BAYU ALFATIR AJI UTOMO','','9480','93',''),(610,'BINTANG DWI RAKA SIWI','','9659','93',''),(611,'CAHYA DELIA HARAHAP','','9446','93',''),(612,'FIOLA SHELOMITHA','','9485','93',''),(613,'FITRI KHOEYRUNISSA HERMAWAN','','9521','93',''),(614,'JELITA ROTUA TAMPUBOLON','','9418','93',''),(615,'JULIAN DWI HERPIANSYAH','','9668','93',''),(616,'LIDESTY APRILLIA AZ ZAHRA','','9690','93',''),(617,'MUHAMAD FAUZY','','9492','93',''),(618,'MUHAMMAD AFDALLUDIN','','9671','93',''),(619,'MUHAMMAD NOUVAL SYAHRY SHANDY','','9641','93',''),(620,'MUHAMMAD RIDHO ELFAIZ','','9425','93',''),(621,'MUHAMMAD TAUFIK','','9599','93',''),(622,'MUHANNAD RAIHAAN','','9392','93',''),(623,'NABIL ARYA HAFIZ','','9427','93',''),(624,'NADIA SABILA','','9568','93',''),(625,'NAURA DHUHA SAEFANI','','9460','93',''),(626,'NAZWA AFRIYANTI','','9532','93',''),(627,'NINDI AULIYA','','9643','93',''),(628,'RAFI NIZAR RAMADHAN ANANDA SUHERMAN','','9464','93',''),(629,'RAYHAN IBNU ARDIAN','','9572','93',''),(630,'RIZQI SUKMA SETIAWAN','','9434','93',''),(631,'SHADRINA PUTRI SYAURA','','9612','93',''),(632,'SYARIFAH NURLAILA','','9647','93',''),(633,'SYBIL LUKELA MAJA ASTI','','9578','93',''),(634,'TASYA SYAFA HASANAH','','9614','93',''),(635,'VIKA AULIA ANANDA','','9579','93',''),(636,'ANASTASYA SEKAR SAPUTRI','','9549','94',''),(637,'ANUGRAH WIJAYANTO','','9621','94',''),(638,'ATSILA TSABITAH SONYA','','9551','94',''),(639,'AULIA KANIA PUTRI','','9552','94',''),(640,'AYUDYA ZAHRAH','','9410','94',''),(641,'DENY GILANG PRATAMA','','9986','94',''),(642,'FADLY ANTO NIANDA SAHPUTRA','','9449','94',''),(643,'FAIHA AQHARID BELLATRIX','','9556','94',''),(644,'FARAH AZALIA MAHARANI','','9415','94',''),(645,'FARREL RAFIF AKMAL','','9557','94',''),(646,'FAVIAN RAFFI PUTRA WIJAYA','','9630','94',''),(647,'HAIDAR GIFFARI AHMAD','','9486','94',''),(648,'KANIA BUTSAINAH','','9420','94',''),(649,'LATIFAH HANUM','','9387','94',''),(650,'MEISYA DHENADA SHAFITRI','','9491','94',''),(651,'MUHAMMAD HAFIZ AL MUNAWWAR','','9566','94',''),(652,'MUHAMMAD IBNU ALIANSYAH','','9601','94',''),(653,'MUHAMMAD RAFIF BAHARUDIN KHODIR','','9672','94',''),(654,'MUHAMMAD RIZKY PRATAMA','','9495','94',''),(655,'MUHAMMAD WILDAN WILDIANSAH','','9642','94',''),(656,'NAILA SALSABILA DAYANI','','9394','94',''),(657,'NAJWA NABILA FIRDAUS','','9982','94',''),(658,'NELI AULIA FATMAH','','9533','94',''),(659,'RAMA GUNTUR JULIANSYAH','','9571','94',''),(660,'RASYA AR`RAZZAAQ','','9644','94',''),(661,'RENDI HERDIANSYAH YUSUF','','9540','94',''),(662,'REYHAN APRIYANA','','9573','94',''),(663,'SALVANA RAMADHANI','','9400','94',''),(664,'SAZQI AULIA','','9542','94',''),(665,'SONY REZA SANJAYA*','','9401','94',''),(666,'THIARA NAVINZA IKHSAN','','9402','94',''),(667,'ZAZKIYA ADILA MIDZA','','9439','94',''),(668,'ZHARUNO RADITYA PUTRA LAKSONO','','9616','94',''),(669,'ABEL DARWIN BUDIANTO','','9369','95',''),(670,'AINI SEPTRIASA','','9547','95',''),(671,'AL BASITH','','9582','95',''),(672,'ALDEN KESTIAN PRAMONO','','9652','95',''),(673,'AULIA NABILA SYAKIRA','','9587','95',''),(674,'AZKIYAH TSURAYAA JIILAAN','','9624','95',''),(675,'CINDY MARWA AZARIA','','9590','95',''),(676,'DAFFA ALFIAN PRATAMA','','9379','95',''),(677,'DIMAS RAFFI ALVARO','','9448','95',''),(678,'DITA AULIA PUTRI','','9381','95',''),(679,'FACHRI ZIDANE NOVALIANO','','9382','95',''),(680,'GHAITSA AZKA SAFANA*','','9522','95',''),(681,'IMADUDIN NUR ALAMSYAH','','9385','95',''),(682,'INDRA AHMAD FAHREZA','','9559','95',''),(683,'JIHAN NUR HASANAH','','9452','95',''),(684,'JOVAN FATHONI KANAYA','','9524','95',''),(685,'KEISA ELIANA','','9525','95',''),(686,'MALIYA ALIMAH','','9421','95',''),(687,'MOHAMMAD ALFATH','','9670','95',''),(688,'MUFTI PERMANA','','9389','95',''),(689,'MUHAMMAD FAJRI BACHTIAR','','9564','95',''),(690,'MUHAMMAD RIZQI AMRI','','9567','95',''),(691,'NADIEN PUTRI ZAELIN','','10242','95',''),(692,'NAFISAH ALIKA PUTRI SUSILO','','9674','95',''),(693,'NAMIRA KHANZA FIRDAUS','','9428','95',''),(694,'NUZULLAH MARFUAH','','9463','95',''),(695,'RAYI KIRANA SASKIA','','9501','95',''),(696,'RIHHADATUL AISY','','9645','95',''),(697,'SULTHAN AFKAR HADZIQ','','9437','95',''),(698,'SYALSABILLAH AURA CINTA','','9613','95',''),(699,'TIA KHOIRUN NISSA','','9648','95',''),(700,'TYFFANNY JOHASSAN','','9472','95',''),(701,'ZAKI RAMADAN','','9580','95',''),(702,'ADINDA KUSUMAWARDHANI PUTRI','','9545','96',''),(703,'ADISA MUFIDAH ZAIN','','9511','96',''),(704,'ADZKIYA NAVISA','','9371','96',''),(705,'ALANZA KINETA PUTRI KUSWARA','','9441','96',''),(706,'AMANDA RIZKIANI','','9406','96',''),(707,'ANNISA CAHYA JULIYANTI','','9375','96',''),(708,'AULYA RIZWAN','','9553','96',''),(709,'DIMAS SATRIO','','9482','96',''),(710,'FACHRI RAMDANI','','9663','96',''),(711,'FADLI SAPUTRA RAHMAN','','9414','96',''),(712,'FAUZI SAPTAMA RAMADHAN','','9594','96',''),(713,'FIKRI RAHMAN KOTO','','9664','96',''),(714,'HAIKAL SETYAKI','','9523','96',''),(715,'HANNAH JUNI MAR BINSARD','','9384','96',''),(716,'KHOLIQ MULYANA','','9526','96',''),(717,'KHUSNUL KHOTIMAH','','9638','96',''),(718,'KINAYA NISFI ARDIYANSYAH*','','9454','96',''),(719,'MAECHEL RADITIYA','','9338','96',''),(720,'MOHAMAD NATSIR SIDIK','','9639','96',''),(721,'MUHAMAD RAMDHAN','','9493','96',''),(722,'MUHAMMAD FEBRIAN SYAH','','9529','96',''),(723,'MUHAMAD RHEVAN ISKANDAR','','10243','96',''),(724,'NATASYA KHAIRANI RAHMASARI','','9497','96',''),(725,'RIANA AULIA','','9575','96',''),(726,'RIFKI DWI CAHAYA','','9610','96',''),(727,'SALSABILA AGUSTINA','','9468','96',''),(728,'SASMITHA ALLEA NANDITYA','','9504','96',''),(729,'SATRIA YUDOYONO','','9576','96',''),(730,'TIARA FIMALYA','','9438','96',''),(731,'VIVIAN NYSSA','','9403','96',''),(732,'ZAHRA KARTIKA','','9649','96',''),(733,'ANNISA HUMAYROH QISSHAH','','9407','97',''),(734,'BELLA NURUL INAYAH','','9377','97',''),(735,'CALLYSTA AUDREY SABIAN','','9589','97',''),(736,'DERY AKBAR','','9447','97',''),(737,'DITO PAMUNGKAS AJI','','9519','97',''),(738,'DIVA DWI ANGGARA','','9555','97',''),(739,'ELVANI SYAKIRA SUSANTO','','9483','97',''),(740,'FARRAS SALVIA LITUHAYU','','9593','97',''),(741,'FREYA CHIQUITA ANINDYA','','9558','97',''),(742,'GHAIDA AZKA DHAWIYAH','','9595','97',''),(743,'GHOZI RAMADHAN','','9417','97',''),(744,'GITA MEYSHILA*','','9632','97',''),(745,'IQBAL ABDUL HAKIM','','9596','97',''),(746,'KHAIRA MEAZZA ERWINPUTRI','','9597','97',''),(747,'KHAIRUL ASFA FUADI','','9489','97',''),(748,'LUTHFIYAH','','9388','97',''),(749,'M. FALZY ALFANZA','','9561','97',''),(750,'MUHAMAD AZZAM BILAL','','9423','97',''),(751,'MUHAMAD HAEKAL RAFLI','','9528','97',''),(752,'MUHAMAD RAMDAN','','9563','97',''),(753,'MUHAMMAD HAIDAR SHALAHUDDIN','','9458','97',''),(754,'NAJWA HANI SAVAIRA','','9459','97',''),(755,'NOVI FAUZIAH','','9462','97',''),(756,'PRIMA FADLI RADIANTAMA','','9535','97',''),(757,'RACHMAD AL-FARHAN','','9606','97',''),(758,'RAFFA FATHURABBANI','','9536','97',''),(759,'RAFI AL ZHAFRAN','','9396','97',''),(760,'RANIA KIRANADESMA','','9538','97',''),(761,'RIZKY ANANTA','','9399','97',''),(762,'SAEPUL BAHCRI','','9503','97',''),(763,'SASVIA NI`MATU ROHMAH','','9470','97',''),(764,'VIRANZA AZHARA','','9615','97',''),(765,'ZIVANNA NAUZIA SYALFIRA','','9474','97',''),(766,'AHMAD RIJAL FAHRI NUHA','','9512','98',''),(767,'ALDI LAKSONO','','9583','98',''),(768,'ALDI SURYA FIRMANSAH','','9372','98',''),(769,'ALIF FIRMANSYAH','','9405','98',''),(770,'ALIFA LETTYSHA PUTRI BUDIYANTO','','9548','98',''),(771,'ALMIRA NABILA SYAKIRA','','9653','98',''),(772,'ANDIKA DWI ARDIANSYAH','','9515','98',''),(773,'ASSYIFA PUTRI ARDINI','','9409','98',''),(774,'ATHANASIUS QUINTO MALAU','','9657','98',''),(775,'AURA SARTIKA DEWI','','9695','98',''),(776,'AUREL JOVIN GRACIA SIAHAAN','','9622','98',''),(777,'BINTANG NUR DZAKIRAH','','9378','98',''),(778,'BRANDON CHRISTIANO SEANE','','9626','98',''),(779,'CAZYA AULIA RAMADHANI','','9518','98',''),(780,'CHRISTOPHER CORNELIUS SIMAMORA','','9627','98',''),(781,'CLARA ALINDYA KESYA','','9591','98',''),(782,'IMMANUEL JOHANES SOEKARNO WULLUR','','9634','98',''),(783,'JONATHAN WILLY','','9636','98',''),(784,'JULIAS PAPUA FABREGAS RUHUPATTY','','9637','98',''),(785,'MASRIYAH','','9455','98',''),(786,'NASYA AULIA PUTRI','','9496','98',''),(787,'NAWWAL EL - KAMAL','','10244','98',''),(788,'NUR FAIZIN','','9498','98',''),(789,'PATRICIA CARLA NINGRUM','','9676','98',''),(790,'RAFAH ALFARIDZI PRIYADI','','9677','98',''),(791,'RAHMAT YUDHA PRATAMA','','9397','98',''),(792,'RENDY ROMA JAYA ARITONANG','','9678','98',''),(793,'RIFDAH WALDAN DAS SYIFA','','9609','98',''),(794,'SAFFA TUZAHRA','','9646','98',''),(795,'SYIFA RAMADANI','','9680','98',''),(796,'WILLYAM TONGGO MARJASA SIHALOHO','','9681','98',''),(797,'YAFETRA WILLIAM SHARON SIHOMBING','','9682','98',''),(798,'YEMIMA ROSVITA LUBIS','','9683','98',''),(799,'ZIVILLIA KHAISARA SUSANTO','','9651','98',''),(800,'ABRIL ADRIAN BASUNI*','','9983','99',''),(801,'ADHISTI WHULANDARI','','9510','99',''),(802,'AL FAIRUZ IZDIHAR','','9617','99',''),(803,'ALFONSIUS SILABAN','','9618','99',''),(804,'ANDI MUHAMMAD ALGEBRA P.L','','10245','99',''),(805,'ANINDA DWI ASTUTI','','9585','99',''),(806,'ANISAH RAHMAWATI','','9655','99',''),(807,'ATTAR DESKHA RAIHANSYAH','','9516','99',''),(808,'AYRA YULIANI','','9692','99',''),(809,'CAROLIN SABRINA MUNTHE','','9660','99',''),(810,'DELLI AULIANI','','9978','99',''),(811,'ELISA MARGARETHA SINAGA','','9662','99',''),(812,'FIKA YUSITA','','9450','99',''),(813,'GABRIEL GERARDO','','9631','99',''),(814,'IDA AYU PARAMITHA ADINDA PUTRI','','9666','99',''),(815,'JEKY SETIAWAN','','9667','99',''),(816,'KAYLA FITRI RAMADHANI','','9488','99',''),(817,'LEANDRO LEONEL DE JESUS DASILVA','','9669','99',''),(818,'MATHEW PAHOTON HOLONG SILAHI','','9985','99',''),(819,'MOCHAMAD SYAHREDZI ATALLAH','','9598','99',''),(820,'MOHAMMAD RIZKI','','9979','99',''),(821,'MUHAMMAD SYABILILLAH AL HAFIZH','','9603','99',''),(822,'MUHAMMAD YUSUF','','9673','99',''),(823,'NUR MAULIDDIAH','','9395','99',''),(824,'NURAINI','','9429','99',''),(825,'RAIHAN PERMANA','','9500','99',''),(826,'RAYSAH ADILA PUTRI','','9539','99',''),(827,'REVAN UKEE ALVINO','','9679','99',''),(828,'RIDHO NUR ROHMAN','','9608','99',''),(829,'SALMAN MOCHAMMAD KHUMAYNI','','9541','99',''),(830,'VELISIA PUTRI','','9508','99',''),(831,'VHIA AGUSTINA RAHMA','','9543','99',''),(832,'YOHANA KRISTANTA AMABEL GULTOM','','9684','99',''),(833,'ZUAN RAYMOND SITANGGANG','','9685','99','');
/*!40000 ALTER TABLE `siswa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tapel`
--

DROP TABLE IF EXISTS `tapel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tapel` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tapel` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `smt` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tahun` varchar(5) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `aktif` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tapel`
--

LOCK TABLES `tapel` WRITE;
/*!40000 ALTER TABLE `tapel` DISABLE KEYS */;
INSERT INTO `tapel` VALUES (2,'2025/2026','2','2026','0'),(3,'2025/2026','1','2025','0');
/*!40000 ALTER TABLE `tapel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_devices`
--

DROP TABLE IF EXISTS `user_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_devices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `device_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_devices`
--

LOCK TABLES `user_devices` WRITE;
/*!40000 ALTER TABLE `user_devices` DISABLE KEYS */;
INSERT INTO `user_devices` VALUES (1,'ME','e498e52563bcc263f0ce9b6170713d661a28d7d51d8f2b8c9966dd839b047f77','2026-01-24 16:56:20','2026-02-23 16:56:20'),(2,'ME','9e54460e08c7f0fd4794a6e972740e5912659f8d94f919ba1d1eafedfb8229bd','2026-01-25 23:56:47','2026-02-24 23:56:47');
/*!40000 ALTER TABLE `user_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usera`
--

DROP TABLE IF EXISTS `usera`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usera` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `nama` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `nik` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `poto` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `status` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '1',
  `ip` varchar(45) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `google_secret` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `email_code` varchar(6) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `email_code_expired` datetime NOT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `level` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '1',
  `idu` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usera`
--

LOCK TABLES `usera` WRITE;
/*!40000 ALTER TABLE `usera` DISABLE KEYS */;
INSERT INTO `usera` VALUES (1,'ME','$2y$10$85xlsiFhjur3/EbI.lRww.JT.ATwySER4bhjelR5Gg5mcMuOS/436','Muharrom Eka',NULL,'1020713','ME_1769190549.jpg','1','::1','IQRTE7N46TGLQLTR','','2026-01-20 04:27:19','2026-01-26 02:20:00','1','1dvjjc4s8apvrest4udk'),(3,'225993','$2y$10$2RekRGvlYHM0odu8A1iFmumtgP/4DqdKD6Nm7db69JXzwG.6ZjmHi','FAJRIYANTO',NULL,'225993',NULL,'1','127.0.0.1',NULL,'','0000-00-00 00:00:00','2026-01-25 04:33:14','2','9ok9itvmpcavjkq9a6lv');
/*!40000 ALTER TABLE `usera` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usera_log`
--

DROP TABLE IF EXISTS `usera_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usera_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `nama` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `waktu` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `ip` varchar(25) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `info` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usera_log`
--

LOCK TABLES `usera_log` WRITE;
/*!40000 ALTER TABLE `usera_log` DISABLE KEYS */;
INSERT INTO `usera_log` VALUES (1,'ME','Muharrom Eka','2026-01-25 05:21:38','127.0.0.1','Login'),(2,'ME','Muharrom Eka','2026-01-25 22:11:45','127.0.0.1','Login'),(3,'ME','Muharrom Eka','2026-01-25 23:56:47','192.168.1.83','Login'),(4,'ME','Muharrom Eka','2026-01-25 23:57:51','192.168.1.83','Login'),(5,'ME','Muharrom Eka','2026-01-26 00:49:56','192.168.1.83','Menghapus Data Prestasi Atas Nama: ABDUR WAFI ALI'),(6,'ME','Muharrom Eka','2026-01-26 02:20:00','127.0.0.1','Login');
/*!40000 ALTER TABLE `usera_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usulan`
--

DROP TABLE IF EXISTS `usulan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usulan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_surat` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `judul` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tujuan` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tgl_dokumen` date DEFAULT NULL,
  `pdf` varchar(200) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usulan`
--

LOCK TABLES `usulan` WRITE;
/*!40000 ALTER TABLE `usulan` DISABLE KEYS */;
/*!40000 ALTER TABLE `usulan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `version`
--

DROP TABLE IF EXISTS `version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `version` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ver` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tgl` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `logupdate` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `ket` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version`
--

LOCK TABLES `version` WRITE;
/*!40000 ALTER TABLE `version` DISABLE KEYS */;
INSERT INTO `version` VALUES (1,'1.0.1','2026-01-02 01:58:54','0','0');
/*!40000 ALTER TABLE `version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'dnet_ad2025'
--

--
-- Dumping routines for database 'dnet_ad2025'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-26  2:28:27
