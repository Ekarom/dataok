-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
--
-- Host: localhost    Database: dnet_ad2025
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `details` text,
  `url` varchar(255) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `duration` varchar(50) DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES (1,'ME','Muharrom Eka','LOGIN','Login','proseslogin.php','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','-','2026-01-24 22:21:38'),(2,'ME','Muharrom Eka','LOGIN','Login','proseslogin.php','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','-','2026-01-25 15:11:45'),(3,'ME','Muharrom Eka','LOGIN','Login','verify_2fa.php','192.168.1.83','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','-','2026-01-25 16:56:47'),(4,'ME','Muharrom Eka','LOGIN','Login','proseslogin.php','192.168.1.83','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','-','2026-01-25 16:57:51'),(5,'ME','Muharrom Eka','DELETE','Menghapus Data Prestasi Atas Nama: ABDUR WAFI ALI','prestasifix.php?&aksi=hapus&urut=14&is_ajax=true','192.168.1.83','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','-','2026-01-25 17:49:56'),(6,'ME','Muharrom Eka','LOGIN','Login','proseslogin.php','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','-','2026-01-25 19:20:00'),(7,'ME','Muharrom Eka','LOGIN','Login','verify_2fa.php','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','-','2026-01-26 00:37:36'),(8,'ME','Muharrom Eka','ADD','Menambah Data Prestasi Atas Nama: ABDUL JALIL HAIDAR ALI','prestasifix.php','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','-','2026-01-26 03:50:56'),(9,'ME','Muharrom Eka','ADD','Menambah Data Prestasi Atas Nama: ABDUR WAFI ALI','prestasifix.php','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','-','2026-01-26 03:52:30'),(10,'ME','Muharrom Eka','DELETE','Menghapus Data Prestasi Atas Nama: ABDUL JALIL HAIDAR ALI','prestasifix.php?&aksi=hapus&urut=15&is_ajax=true','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','-','2026-01-26 03:53:30'),(11,'ME','Muharrom Eka','DELETE','Menghapus Data Prestasi Atas Nama: ABDUR WAFI ALI','prestasifix.php?&aksi=hapus&urut=16&is_ajax=true','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','-','2026-01-26 03:54:03');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbset`
--

DROP TABLE IF EXISTS `dbset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dbset` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dbname` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tahun` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `aktif` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbset`
--

LOCK TABLES `dbset` WRITE;
/*!40000 ALTER TABLE `dbset` DISABLE KEYS */;
INSERT INTO `dbset` VALUES (1,'dnet_ad','2024','0'),(2,'dnet_ad2025','2025','1');
/*!40000 ALTER TABLE `dbset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legalisir`
--

DROP TABLE IF EXISTS `legalisir`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `legalisir` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_surat` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tgl_dokumen` varchar(200) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `ditujukan` varchar(300) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `perihal` varchar(200) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `pembuat` varchar(25) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `pdf` varchar(200) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legalisir`
--

LOCK TABLES `legalisir` WRITE;
/*!40000 ALTER TABLE `legalisir` DISABLE KEYS */;
INSERT INTO `legalisir` VALUES (1,'test','2026-01-25','test','test','test','2025/20260125_test_test_piagam_3.pdf');
/*!40000 ALTER TABLE `legalisir` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `ip_address` varchar(45) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `attempts` int NOT NULL,
  `last_attempt_time` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ip` (`ip_address`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migration_test`
--

DROP TABLE IF EXISTS `migration_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migration_test` (
  `id` int NOT NULL AUTO_INCREMENT,
  `test_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration_test`
--

LOCK TABLES `migration_test` WRITE;
/*!40000 ALTER TABLE `migration_test` DISABLE KEYS */;
INSERT INTO `migration_test` VALUES (1,'Migration System working!');
/*!40000 ALTER TABLE `migration_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `executed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestasi`
--

DROP TABLE IF EXISTS `prestasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prestasi` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pd` varchar(99) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kelas` varchar(25) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `prestasisiswa` varchar(99) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `jenisprestasi` varchar(99) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tgl_kegiatan` varchar(80) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tingkat` varchar(99) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `lokasi` varchar(88) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `pdf` varchar(200) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestasi`
--

LOCK TABLES `prestasi` WRITE;
/*!40000 ALTER TABLE `prestasi` DISABLE KEYS */;
/*!40000 ALTER TABLE `prestasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profils`
--

DROP TABLE IF EXISTS `profils`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profils` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nsekolah` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `npsn` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `alamat` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kecamatan` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kelurahan` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `provinsi` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kabupaten` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kodepos` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `no_telp` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `website` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `nipkasudin` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `nrkkasudin` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kasudin` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kepsek` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '-',
  `nipkepsek` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '-',
  `nrkkepsek` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `pengawas` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '-',
  `nippengawas` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '-',
  `nrkpengawas` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kasi` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs DEFAULT '-',
  `nipkasi` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '-',
  `nrkkasi` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `ktu` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `nipktu` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `nrkktu` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `logo_sekolah` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT 'logo_default.png',
  `background_login` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT 'bg_default.jpg',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profils`
--

LOCK TABLES `profils` WRITE;
/*!40000 ALTER TABLE `profils` DISABLE KEYS */;
INSERT INTO `profils` VALUES (1,'SMP Negeri 171','20103617','Jl. SMP 171 No.18','Ciracas','Rambutan','DKI JAKARTA','Jakarta Timur','13740','0218414989','mail@smpn171.sch.id','smpn171.sch.id','','','HORALE TUA','SUHARTO, S.Pd','-','','Drs. Baharuddin Dalimunthe.M.M','-','-','Tuti Agiawati','-','','SYARIFAH MASNAENI, S.Pd','','','logo_sekolah_1766127900.png','bg_default.jpg');
/*!40000 ALTER TABLE `profils` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `runtxt`
--

DROP TABLE IF EXISTS `runtxt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `runtxt` (
  `id` int NOT NULL,
  `txt` varchar(250) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `runtxt`
--

LOCK TABLES `runtxt` WRITE;
/*!40000 ALTER TABLE `runtxt` DISABLE KEYS */;
/*!40000 ALTER TABLE `runtxt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server`
--

DROP TABLE IF EXISTS `server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `server` (
  `id` int NOT NULL,
  `weboff` varchar(2) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `log_server` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server`
--

LOCK TABLES `server` WRITE;
/*!40000 ALTER TABLE `server` DISABLE KEYS */;
/*!40000 ALTER TABLE `server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `siswa`
--

DROP TABLE IF EXISTS `siswa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `siswa` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pd` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `jk` varchar(5) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `nis` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `kelas` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `photo` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=862 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `siswa`
--

LOCK TABLES `siswa` WRITE;
/*!40000 ALTER TABLE `siswa` DISABLE KEYS */;
INSERT INTO `siswa` VALUES (1,'BAGAS BIL FAQIH','L','10000','8.2',''),(2,'BINTANG LANGIT CAESAR MMBUMI','L','10001','8.3','10001.jpg'),(3,'BINTANG OZIL VALERIAN','L','10002','8.6','10002.jpg'),(4,'CALLYSTA KEYSHA NOVIANTI','P','10003','8.6','10003.jpg'),(5,'DEANA NAZWA KUSUMA','P','10004','8.6','10004.jpg'),(6,'FADLI LUTFI HIBATULLAH AL SUNNI','L','10006','8.5','10006.jpg'),(7,'MARSYA AULIA','P','10011','8.7','10011.jpg'),(8,'MUHAMMAD HAIKAL RAMADHAN','L','10016','8.4','10016.jpg'),(9,'MUHAMMAD RUSDI THAMRIN','L','10019','8.1','10019.jpg'),(10,'NADHIRA PERMATASARI','P','10021','8.6','10021.jpg'),(11,'NASHITA PUTRI RAMADHANI','P','10022','8.6','10022.jpg'),(12,'RAFIF JUNANDA','L','10026','8.7','10026.jpg'),(13,'YASMINE SYABILA PUTRI','P','10027','8.3','10027.jpg'),(14,'ABHINAYA RAFFATA ADHAZA','L','10028','8.4',''),(15,'ALIYYA LATHIFAH','P','10030','8.1',''),(16,'ANZIYAA ZALIKA','P','10031','8.4',''),(17,'AQIILA DESVIANA','P','10032','8.5',''),(18,'JAUZAA FIRDAUSI','P','10043','8.6',''),(19,'MUHAMMAD RIZKI AKHYAR DALIMUNTE','L','10049','8.7',''),(20,'NADIA PUTRI ZHAFIRA MUSLIMAH','P','10051','8.3',''),(21,'RAFFI AHMAD SOFYAN','L','10055','8.4',''),(22,'RANGGA SAPUTRA','L','10056','8.4',''),(23,'RIDHWAN AULIA','L','10057','',''),(24,'SYIFA KHOIRUNNISA','P','10060','8.3',''),(25,'WURYANTI','P','10061','8.7',''),(26,'ADILA ZIADATUL HUSNA','P','10064','8.2',''),(27,'AIDAN IBRAHIM MANAN','L','10065','8.1',''),(28,'AJENG FITRI HANDAYANI','P','10066','8.6',''),(29,'ALIFAH FARAH DZAKIYAH BACHTIAR','P','10067','8.3',''),(30,'ANANDA ABRAR MU\'IZZ','L','10069','8.4',''),(31,'ANNISA MAULIDA','P','10070','8.7',''),(32,'DHIA SILMI ATIYAH','P','10072','8.4',''),(33,'FAHMI RASYIQ AISY','L','10073','8.1',''),(34,'FAINE ADIRATNA MARTIN','P','10074','8.2',''),(35,'FIKRI RADITYA AL FARIZI','L','10076','8.3',''),(36,'FULVYA TALITHA NURSYIFA','P','10077','8.3',''),(37,'MIKHAYLA RAJWA AZALIA LONDORAN','P','10080','8.4',''),(38,'MUHAMMAD FADLAN KHAIRUL ANAM','L','10083','8.1',''),(39,'MUHAMMAD RADITYA PRATAMA','L','10085','8.6',''),(40,'RAFFA GHARIN ARCADIA','L','10090','8.6',''),(41,'TANISHA AURELIA KHALFANY','P','10093','8.1',''),(42,'ZHIVANA MEILOVA','P','10096','8.6',''),(43,'ARYA BINTANG MAHARDHIKA','L','10101','8.3',''),(44,'AULIA NAZHIFAH RIZLIN','P','10102','8.1',''),(45,'AZRA YUSUF ALBANI-RAY','L','10104','8.4',''),(46,'FAZA KHAIRINA DIRGANTARA','P','10109','8.3',''),(47,'NAYLA NUR FITRIAH','P','10117','8.5',''),(48,'NHAURA FATHIYYAH ISKANDAR','P','10118','8.7',''),(49,'NOVA INDAH SYAFITRI','P','10119','8.4',''),(50,'NURKHOLIS SHAFWAN BARDIANTO','L','10120','8.2',''),(51,'ROBIE AHMADIN ZIDANE','L','10127','8.1',''),(52,'WELLNES HUMAIRA GHASSANI','P','10132','8.4',''),(53,'ALWAN SATRIA PUTRA','L','10135','8.5',''),(54,'AREVA ANASTASYA','P','10138','8.2',''),(55,'BUNGA KEYLA FITRIAWAN','P','10139','8.2',''),(56,'DAREL DYRA DYAKSA','L','10141','8.1',''),(57,'FARRELVINO JULIANSYAH','L','10142','8.3',''),(58,'FAYRUZ ZAKI HARDIAN','L','10143','8.7',''),(59,'FITRI MULYANINGSIH','P','10145','8.6',''),(60,'GUNTUR ALHAADY','L','10146','8.1',''),(61,'HERNAWAN VICKY FAUZI','L','10148','8.3',''),(62,'MELIA ASHYABELLA','P','10152','8.6',''),(63,'MUHAMMAD NAUFAL AZZAM','L','10156','8.3',''),(64,'RABBANI BISMA ABIMANYU','L','10161','8.5',''),(65,'RADITYA KAFI AKBAR PRATAMA','L','10162','8.4',''),(66,'RAHMAT HIDAYAT','L','10163','8.5',''),(67,'WAHID KHAIRUL AZZAM','L','10167','8.2',''),(68,'WARDANA BAHARI','L','10168','8.3',''),(69,'ALINDA FADIAH ZIHNI','P','10171','8.3',''),(70,'CAHYA AUFA ATIQAH','P','10174','8.2',''),(71,'CALVIN BASTIAN RIENOS','L','10175','8.6',''),(72,'DEVIAN DZIKRI ARRAYAN','L','10176','8.7',''),(73,'DIVA KHAIRUNNISA','P','10178','8.3',''),(74,'FAREL HARTONO','L','10179','8.6',''),(75,'KAREN STEPHANI','P','10183','8.6',''),(76,'KHALISHA SALSABILA FATHURRAHMAN','P','10184','8.1',''),(77,'MELVYN HIEGO ANRESI LIAN','L','10188','8.6',''),(78,'MUHAMMAD AKBAR FAIS RIFA\'I','L','10189','8.2',''),(79,'MUHAMMAD JAWWAD','L','10191','8.3',''),(80,'MUHAMMAD RAKHA RAJENDRA','L','10193','8.2',''),(81,'NADHIRA HARDIANSAH MAULIDA','P','10195','8.4',''),(82,'NATASYA REVINA NAIBAHO','P','10196','8.7',''),(83,'PAJRI PRATAMA','L','10198','8.2',''),(84,'RADHA NADA ADRYANA GINTING','P','10199','8.6',''),(85,'SAMUEL DESHAWN JACOB SIAHAAN','L','10202','8.6',''),(86,'VINNO ARDIANSYAH','L','10203','8.3',''),(87,'AKHTARIZAL HASAN','L','10206','8.4',''),(88,'ARSYA AMANDA PUTRI','P','10207','8.1',''),(89,'ARUNG NAWAYKA ISKANDAR','L','10208','8.4',''),(90,'CRISNATAL ALOYSIUS PUTRA SITUMORANG','L','10212','8.6',''),(91,'JONATHAN NATANAEL','L','10221','8.7',''),(92,'KHALISA RANIA PUTRI','P','10222','8.7',''),(93,'MELODY ABIGAIL','P','10226','8.7',''),(94,'NAZWA ASAELLA FEBRIANTI','P','10233','8.5',''),(95,'PUSPA AYUNINGTYAS HAPSARI','P','10235','8.6',''),(96,'RAFISQY HANIFAN PUTRA SUSANTO','L','10236','8.7',''),(97,'AKASYAH ANASTASYA','P','10248','8.1',''),(98,'SYAKILA SYAFIUL ILMI','P','10250','8.1',''),(99,'FAVIAN DEFARO ANGGARA SUTANDI','L','10252','8.3',''),(100,'IRGI ADITYA PRATAMA','L','10254','9.1',''),(101,'SITI ALAWIYAH','P','10576','7.2',''),(102,'FAZLE MAWLA EDELWEISH','L','10579','7.4',''),(103,'INTAN KARISA DEWI','P','10582','7.2',''),(104,'MUHAMMAD KEISYA RAMADHAN','L','10585','8.6',''),(105,'MALVIN HARIYANTO','L','10586','8.7',''),(106,'YUNA AULIA','P','10587','7.3',''),(107,'DEANDRA MAHESWARI FIRZANAH','P','10589','7.1',''),(108,'SAFIQ AZZAM AL HAFIZ','l','10570','7.6',''),(109,'SITI ALYA SYAKILLA AZZAHRA','p','10540','7.7',''),(110,'TSAQIF ARAFAH','l','10447','7.4',''),(111,'REVAN SHALKAUSAR','l','10572','7.5',''),(112,'NAFLAH AISYATUL FAUZIAH','p','10573','7.2',''),(113,'CINTA AZURA IDRIS','p','10574','7.1',''),(114,'AMANDA AMELIA HAPSARI','p','10404','7.4',''),(115,'RIZKY PUTRA PRATAMA HELDY','l','10468','7.8',''),(116,'FIDELYA AIKO PRATAMA','P','10340','7.5',''),(117,'FARIDZ ALI HAKKI','L','10308','7.9',''),(118,'MUHAMMAD ARBI PRATAMA','L','10323','7.6',''),(119,'HENDRUS GIOVANNI PANGIHUTAN SINAGA','l','10429','7.8',''),(120,'ADIEL CINTA CATLEYA MAMPUK','P','10331','7.8',''),(121,'ARKANANTA ABRISAM SAMSUDIN DYAKSA','L','10339','7.4',''),(122,'EVANGELINE FELICIA STEPHANIE','P','10284','7.8',''),(123,'HANGGIA RAISYADINA SIREGAR','P','10338','7.3',''),(124,'MUHAMMAD RASYA ARGANI','l','10549','7.7',''),(125,'ARGA SIMANUNGKALIT','L','10387','7.9',''),(126,'ARGANI BINTANG KUMARA','L','10402','7.7',''),(127,'FADHO ALPHARD APANDI','L','10315','7.7',''),(128,'JASMINE SALSABIL KHAIRUNNISA','P','10382','7.4',''),(129,'RAYHAN NADHAVI WIBOWO','L','10401','7.6',''),(130,'SYAKIRA DISA DINANTI','P','10305','7.6',''),(131,'NAILA APRILIYANTI','P','10327','7.1',''),(132,'REVINO TRISNA DWI UTAMA','l','10466','7.5',''),(133,'REYSHA RIDWANEZKA','P','10391','7.2',''),(134,'ILHAM NURRIZKY','l','10455','7.3',''),(135,'JASMINE AULIA PUTRI','P','10341','7.6',''),(136,'MUHAMMAD HAIKAL SASTRANEGARA','l','10507','7.1',''),(137,'AZKA RABBANI','l','10486','7.7',''),(138,'KALIA AMAZONA KARERA','p','10523','7.8',''),(139,'NURSYAILA APRIANI','p','10562','7.1',''),(140,'SUCI KEYLA SYAFITRI','p','10465','7.4',''),(141,'SYAFIERA ANGGRAINI','P','10396','7.1',''),(142,'TRI WULANDARI','p','10467','7.6',''),(143,'AISYAH DEWI CANDANI','P','10398','7.3',''),(144,'BERLIAN PUTRI ANGGRAYNI','p','10473','7.3',''),(145,'KHAIRA INAYAH ALVIZA','p','10487','7.2',''),(146,'NAUFAL FADLAN ALFIANSYAH','L','10332','7.6',''),(147,'PUTRI INDAH PERTIWI','p','10528','7.3',''),(148,'DAVINA FAIZAH AUNILLAH','P','10335','7.3',''),(149,'RAFA ADITYA WIDODO','l','10541','7.8',''),(150,'ABSHARI FARANISA ISLAMI','P','10334','7.4',''),(151,'FAKHRI AQIL TAMAM','l','10499','7.2',''),(152,'DIMAS SATRIA PRIANGGODO','L','10282','7.1',''),(153,'ELZO LINTANG NUSANTARA','L','10352','7.6',''),(154,'MUHAMMAD RAFADHILAH AZZAMI','L','10310','7.2',''),(155,'MUHAMMAD SAUQI HABIBI','L','10344','7.4',''),(156,'MUHAMMAD YUNUS HABIBI','L','10356','7.2',''),(157,'RIDWAN KURNIAWAN','l','10533','7.3',''),(158,'SHAFA SHASHA LIDYA','P','10385','7.7',''),(159,'ALMIRA FALISHA MAULIDYA','P','10285','7.4',''),(160,'GILBERTO MICHAEL NGGENDA','l','10575','7.9',''),(161,'RAFFA ADITYA AINNURRAIS','l','10514','7.8',''),(162,'FAHMI FATURAHMAN','L','10368','7.3',''),(163,'HUSNA LABIBAH','P','10363','7.2',''),(164,'ICE TRI NOPEBRIANI','P','10345','7.9',''),(165,'JENNIFER CALISTA ELIZABETH SIAHAAN','P','10276','7.9',''),(166,'MUHAMMAD RAFLI FABREGAS','L','10322','7.5',''),(167,'MUHAMMAD TETEN MUFTHI NUR YUSYA','L','10289','7.8',''),(168,'RAKA ERLANGGA BAHRIE','l','10498','7.1',''),(169,'RYAN FEBRIAN','L','10380','7.2',''),(170,'DHIKA PRASETYA','l','10545','7.4',''),(171,'SHIREEN AQUEENA VIANSYAH','P','10392','7.8',''),(172,'RAIHAN PUTRA UTAMA','L','10299','7.9',''),(173,'RAIHAN ZAKI SYARIF','L','10318','7.1',''),(174,'SIFA AULIA FIRMANSYAH','P','10366','7.5',''),(175,'DANISHA AZZAHRA BALQIS','P','10295','7.5',''),(176,'NUR LAELA SALMA','p','10423','7.7',''),(177,'TIARA FAUZIAH','p','10542','7.6',''),(178,'ZIBRAN HENRIKO','l','10515','7.9',''),(179,'ARDIANSYAH REZA','l','10495','7.7',''),(180,'MUHAMMAD SATRIA FEBRIAN SAPUTRA','L','10312','7.5',''),(181,'RAFFAEYZA DANISH SATRIO NUGROHO','L','10302','7.3',''),(182,'RAIHANAH FAIHA HASNA','p','10501','7.4',''),(183,'HILDA DWI NUR SUSANTI','p','10475','7.5',''),(184,'KAYLA AVRILLIA','p','10563','7.3',''),(185,'KHALILA AZZAHRA PUTRI','P','10293','7.3',''),(186,'MUHAMMAD LUTHFI ELFAREZKY','L','10294','7.4',''),(187,'NIKEISHA DZAKIRA ASADI','P','10319','7.2',''),(188,'QUANEISHA DZAKIRA ASADI','P','10321','7.4',''),(189,'ALYYA RAFANA YUNIA RIZKY','P','10301','7.2',''),(190,'FAHIRA NANDA ANGGRAINI','p','10505','7.6',''),(191,'SITI NUR SYIFAH','p','10457','7.5',''),(192,'MUHAMMAD KHADAFI','l','10484','7.5',''),(193,'MUHAMMAD RAIHAN PUTRA JAYANTO','L','10259','7.5',''),(194,'NUGIE RAIHAN APRIANSYAH','l','10548','7.6',''),(195,'SHALMA YUANDINI','P','10389','7.9',''),(196,'SHILVIA INDRY','P','10268','7.5',''),(197,'SYADAN AL FARIZI','L','10260','7.6',''),(198,'ZASKIA PUTRI AZZAHRA','P','10258','7.4',''),(199,'DIVA AULIA PUTRI','p','10469','7.7',''),(200,'CITRA DINATHA','p','10452','7.9',''),(201,'KIREINA ANNURUNISA','P','10257','7.3',''),(202,'MUHAMMAD RAFI ADITYA','L','10347','7.3',''),(203,'NUR AZIZAH BUDIMAN','P','10362','7.1',''),(204,'AZZAHRA NABILA PUTRI','p','10566','7.6',''),(205,'BINTANG VIRIYA WIJAYA','l','10568','7.8',''),(206,'FADEL ABDUH NIZAM','l','10525','7.2',''),(207,'MUHAMMAD RIFKY ALDIANSYAH','l','10513','7.7',''),(208,'NADZRIL AZKA RAIHAN','L','10316','7.1',''),(209,'NOVAL DHARMA SETIADY','L','10309','7.8',''),(210,'RIZKA NABILLAH','P','10397','7.2',''),(211,'SHERYL NAURA SYAHLA','P','10304','7.5',''),(212,'SOFIAN HADI','L','10400','7.4',''),(213,'ALIYA BUNGA JANUARI','P','10403','7.8',''),(214,'ALYSSA AZKADINA SUSANTO','p','10510','7.4',''),(215,'AZKIYA INDRIAN NAYLA','p','10502','7.5',''),(216,'DINDA LESTARI','p','10526','7.1',''),(217,'KAYLA FALISHA PUTRI','P','10296','7.6',''),(218,'VIRA','p','10442','7.3',''),(219,'ARYA RIZKI PERMANA','l','10527','7.4',''),(220,'DAFFA MUSYAFFA','l','10558','7.7',''),(221,'AMIRAH MULYANTI','p','10538','7.5',''),(222,'ATIKAH NUR AUYLIA','p','10567','7.7',''),(223,'KENZI KAYANA RAFASYA','l','10554','7.3',''),(224,'MICHEL NUR MALIKI','l','10509','7.3',''),(225,'RAHAGI RADIANDRA ADENTA','l','10448','7.5',''),(226,'ZAIN LUTHFAN HAKIM','l','10456','7.4',''),(227,'ADRYAN WIRADARMA','l','10489','7.1',''),(228,'AHMAD ZHAFIR RIZQI','l','10488','7.9',''),(229,'ALVARO SATRIA HARTOYO','l','10534','7.1',''),(230,'ANDHIKA FEBRIANTO','l','10479','7.2',''),(231,'AZAM MAULANA ARIEF','l','10464','7.3',''),(232,'AZZAHRA ZULAYKA WIDYA','p','10537','7.3',''),(233,'DAFFA ZAIDAN LEANDY PUTRA','L','10329','7.2',''),(234,'EKKI DWI ANDRIANTO','l','10543','7.1',''),(235,'FAQIH DZAKWAN NUGROHO','L','10278','7.6',''),(236,'KHOIRUN NISA','p','10517','7.1',''),(237,'MAWAR PUSPITA DEWI','P','10275','7.3',''),(238,'MUHAMMAD FADJERULLAH SYAHLULLAIL','l','10547','7.5',''),(239,'MUHAMMAD RAFKA PRATAMA','l','10524','7.9',''),(240,'MUSTIKA AMELIA','P','10325','7.5',''),(241,'NAICYLA DIANDRA','P','10328','7.3',''),(242,'NOVAL HADIWIJOYO','l','10449','7.6',''),(243,'RAHMA FITRIANI PERMANA','P','10264','7.1',''),(244,'RAJWA ARKAAN','l','10535','7.2',''),(245,'RIZKI PRANATA PUTRA','l','10551','7.9',''),(246,'SALMA HUMAIRA','P','10273','7.1',''),(247,'SYILFIA AFRILI NANUSELLA','p','10546','7.9',''),(248,'VARENDRA RAMADHAN CAHYA AMIEGOES','L','10279','7.7',''),(249,'VICTORIA MARTHAULINA SILABAN','P','10330','7.8',''),(250,'ZLATAN ARSHYA ARUNA','p','10506','7.9',''),(251,'BUNGA KIRANA','p','10416','7.6',''),(252,'NABILA FARAH EFFENDI','P','10256','7.2',''),(253,'ZAHIRA DWI FEBRIANI','p','10493','7.5',''),(254,'JAISYULLOH AL JASIR HARSYAH','l','10494','7.6',''),(255,'NADA SYAHIRA','P','10262','7.8',''),(256,'TESSA ANASTESIA BUDIMAN','P','10337','7.2',''),(257,'TIARA ESTY MAHDALENA','P','10267','7.4',''),(258,'AURELLIA MORI SIHALOHO','p','10520','7.9',''),(259,'JANUAR JAMIL','L','10298','7.3',''),(260,'KEITHA ARAYA ANINDITYA','p','10496','7.8',''),(261,'AL BIMA IBRAHIM','l','10435','7.1',''),(262,'ZAHRA DESWITA MAHARANI','p','10454','7.2',''),(263,'RESKI DWI FEBRIANTO','l','10480','7.1',''),(264,'NUFAH DEKA PUTRA','l','10561','7.2',''),(265,'AZKA LANGITARFANSYAH','L','10317','7.9',''),(266,'GIBRAN ASKA KELLANA','l','10560','7.9',''),(267,'MUHAMMAD RAFI ARDIANSYAH','l','10550','7.6',''),(268,'AHMAD DZALALLUDIN AKBAR','l','10426','7.1',''),(269,'ANTONIUS ADYTAMA NEBO BEGUIR','l','10408','7.8',''),(270,'FALIH UBAIDILAH','l','10410','7.2',''),(271,'INAYAH RAMADHANIA ARFAN','P','10274','7.2',''),(272,'MARSYAH PUTRI','p','10565','7.5',''),(273,'MOHAMAD HASBI MUBAROK','L','10378','7.5',''),(274,'RADINDHA PUTRI ANGGRAINI','p','10418','7.2',''),(275,'SAFA ALIYAH RAHAYU','P','10373','7.3',''),(276,'FARID EVAN FADILAH','l','10409','7.3',''),(277,'FITRA ALAM','L','10367','7.7',''),(278,'IRSYAD ATHAR SYARIF','L','10348','7.4',''),(279,'MOHAMMAD FAZRI AL GHOZALI','L','10377','7.6',''),(280,'MUHAMMAD FIKRI ZAIDAN','L','10376','7.4',''),(281,'PATRICIA JOVANCA CHRISTIANA SARI','p','10413','7.9',''),(282,'RAHMA INDAH PERMATA','p','10414','7.7',''),(283,'SAVIRA CAHYA KAMILA','p','10522','7.7',''),(284,'AFFAN ARKANANTA YUDHISTIRA','L','10303','7.4',''),(285,'AZKA MAHENDRA YUDHISTIRA','L','10307','7.8',''),(286,'MUHAMAD ADITYA RIZKI','l','10438','7.4',''),(287,'MUHAMMAD RIZKI RAMADHAN','l','10412','7.5',''),(288,'PUTRI NURUL MEILANI','p','10425','7.5',''),(289,'TSABIT WILIS HAFIZH','l','10453','7.1',''),(290,'AISHA SADINA MARITZA','P','10342','7.8',''),(291,'ALFIANSYAH SAPUTRA','L','10333','7.7',''),(292,'AZUAN SYAHRIL HARSONO','L','10371','7.7',''),(293,'MOHAMAD ARIL OKTAV','L','10372','7.3',''),(294,'NIKEISHA YUDHIRA AZZAHRA','p','10497','7.9',''),(295,'ANJANI DESWITA','P','10375','7.4',''),(296,'ATHAR FREDRICO NAILENDRA','l','10424','7.8',''),(297,'FIQRI AHMAD FIRDAUS','L','10395','7.2',''),(298,'IMMACULATA ROSECHARLOTA BELLE','p','10419','7.8',''),(299,'KHANSA JANEETA AL AMRIE','p','10436','7.9',''),(300,'LIDIA ARTINI SIPAYUNG','p','10422','7.9',''),(301,'MARVELL MAYNARD HASUDUNGAN','L','10369','7.8',''),(302,'MUHAMMAD HAIKAL','l','10459','7.7',''),(303,'FAIZAH NUR\'AN SHABIRA','P','10361','7.6',''),(304,'FARAH NUR MAULIDA','P','10270','7.7',''),(305,'LIZA KAYLA PUTRI','p','10406','7.6',''),(306,'WINDI SEPTIANI','p','10427','7.2',''),(307,'ALVIN ABHYASA UTOMO','l','10478','7.1',''),(308,'AZLAN PUTRA FADILLAH GINTING','L','10320','7.9',''),(309,'ADRIAN KAVIN ABDULLAH','L','10394','7.5',''),(310,'AULIYA FAUZIYAH SANUSI','p','10500','7.3',''),(311,'BAGAS ADITYA ALFARIZI','l','10529','7.5',''),(312,'DANI FERNANDES','l','10476','7.8',''),(313,'KHANZA RAE\'ESAH DARAJAT','p','10521','7.6',''),(314,'LAILATUR ROHMAH','P','10306','7.7',''),(315,'MIKHAEL LATUMAHINA','l','10472','7.8',''),(316,'MUHAMMAD IKHSAN MAULANA','l','10432','7.7',''),(317,'VANY NOVANTY TENDA','p','10557','7.4',''),(318,'CAHDRA HERMAWAN','l','10433','7.8',''),(319,'RADITHYA PERMATA','l','10559','7.8',''),(320,'YENI RAHMAN','p','10503','7.6',''),(321,'FARIZ MUHAMMAD ALFARIZI','l','10446','7.3',''),(322,'INDRIYANI AGUSTINA SAFITRI','P','10351','7.7',''),(323,'JIHAN ELZA SHIDIQ','p','10519','7.3',''),(324,'MIKAEL CANTIKA IMROATU SHOLIHAH','P','10383','7.5',''),(325,'MUHAMAD ROGIBIN ASOPARI','L','10381','7.3',''),(326,'MUHAMMAD AZZAM KHOIRUDIN','l','10553','7.2',''),(327,'SHELVA SAFANA AZAHRA','p','10460','7.8',''),(328,'ZIANKA RACHELIKA','p','10539','7.9',''),(329,'ALIYA AZAHRA NOVIYANTI','P','10359','7.1',''),(330,'CINTA PUTRI APRILIA','p','10555','7.4',''),(331,'MUHAMAD RIDWAN','l','10463','7.2',''),(332,'MUHAMMAD CAVANI','L','10346','7.3',''),(333,'NAYYARA ADREENA ALMAHYRA','p','10481','7.2',''),(334,'TRIBUANA SANDHI YUDHA SAKTI','L','10358','7.2',''),(335,'CAHAYA VITRI','p','10430','7.5',''),(336,'CHERYL AURELIE PRABOWO','P','10265','7.2',''),(337,'FARRAS PARSA HABIHAN','l','10434','7.9',''),(338,'FAZRI IBRAHIM','l','10491','7.3',''),(339,'MALLIKA ATAYYA PRIANA','P','10286','7.5',''),(340,'AISYAH NILAM CAHYA','P','10388','7.7',''),(341,'AKHMAD CITO AL-FAIZ','L','10393','7.4',''),(342,'ARMIA ZABIR','L','10390','7.1',''),(343,'CHERYL ALMIRA FLORENCIA','P','10288','7.9',''),(344,'MUHAMMAD FADHILA','l','10482','7.3',''),(345,'MUHAMMAD IZZAN YOFAN','l','10492','7.4',''),(346,'RACHEL ADITYA PRASETYO','l','10431','7.6',''),(347,'FEBRI DWI ARYANTO','L','10349','7.5',''),(348,'LAURENCIA DAVINA SITUMORANG','p','10485','7.8',''),(349,'PERMATA NADA AL RAHMA','p','10437','7.3',''),(350,'SATRIO ADLAN RAHARJO','L','10271','7.8',''),(351,'BANYU PUTRA PRATAMA','l','10518','7.4',''),(352,'DAFINAH KHANSA','P','10287','7.6',''),(353,'NAYLA ANINDYA JASMINE','p','10504','7.7',''),(354,'ZHEN DZARIFFA QUEENA','p','10474','7.4',''),(355,'CARISSA SYAILA MAHYA','P','10357','7.1',''),(356,'JASMINE IFRA FEBRIANA','p','10483','7.4',''),(357,'KHALFANI AL HAFIZH','L','10314','7.6',''),(358,'MUHAMMAD ILHAM FIRMAN SYAH','l','10511','7.5',''),(359,'RAHMAT TAJUL \'ARIFIN PANGGABEAN','l','10462','7.6',''),(360,'SABIQAH NUR AZZAHRA','p','10530','7.6',''),(361,'ZAIDAN RIFQI SAKHA','L','10290','7.7',''),(362,'IVANKA CLAUDEALOVA KRISANDY','p','10411','7.9',''),(363,'JELITA HAIRUN NISA','p','10461','7.9',''),(364,'QIYANU PUTRA SUDRAJAT','L','10283','7.2',''),(365,'QUINCY KHLOE ARNOLDIE SIAHAAN','p','10415','7.8',''),(366,'RUMATHA KAYLA IVANA TAMPUBOLON','P','10269','7.8',''),(367,'SYIFA FAUZIAH','P','10280','7.8',''),(368,'AFIKA JULIANTI RAMADHANIA','P','10350','7.7',''),(369,'ATHALLA RAYANDRA','l','10443','7.9',''),(370,'AZKIYA MUFIDAH','P','10297','7.7',''),(371,'IBRAHIM MUFIID','l','10450','7.7',''),(372,'RIDHO BAGUS ALFARIDZI','L','10386','7.8',''),(373,'FAHMI ACHMAD SUMARTO','L','10281','7.4',''),(374,'LUTFI SANIYATU SABILA','p','10471','7.1',''),(375,'ALIVIA REYSUNAH','P','10399','7.5',''),(376,'AZKIA MAULIDA','P','10291','7.1',''),(377,'ANISA RIZKI AULIA','p','10451','7.4',''),(378,'IBRAM MAULANA BAHARRIZKI','L','10277','7.5',''),(379,'MELYANA KARTIKA','p','10458','7.6',''),(380,'QIERAN CYRIEL RIENZHIANI','P','10365','7.8',''),(381,'ROSMALINA PUTRI','p','10531','7.7',''),(382,'SEPTIAN RAHMADHANI','L','10353','7.6',''),(383,'MIKAELA DELTA HUTAGAOL','P','10364','7.9',''),(384,'MUHAMMAD ADLIN ABYUDAYA','L','10379','7.1',''),(385,'VIRGO KURNIAWAN SEPTIANTO','L','10354','7.9',''),(386,'DEVI RIYANTI RITONGA','P','10324','7.9',''),(387,'HASBI ARJUNAFISAL HUDA','l','10512','7.6',''),(388,'IBRA FAHRUREKI','l','10490','7.2',''),(389,'JANEETA AFIQA','P','10336','7.1',''),(390,'JIHAN DAMAYANTI','p','10477','7.7',''),(391,'MUHAMAD SYARIF HIDAYAT','l','10536','7.4',''),(392,'MUHAMMAD FIKRI ABDILLAH','l','10532','7.8',''),(393,'PUTRI AISYAH','P','10263','7.7',''),(394,'RIZQY PERMATA AL HUDA','l','10544','7.2',''),(395,'MUHAMMAD YUDHA PUTRANTO','L','10370','7.6',''),(396,'HAIZA HASFIRANA RAUFAH','P','10266','7.3',''),(397,'ELANG NIRZA RIZQI RAMADHAN','l','10405','7.1',''),(398,'ELIZA ANABELLA RAMBE','P','10311','7.8',''),(399,'HUMAIRA PUTRI RANIA','p','10444','7.1',''),(400,'FITRI DWI ASTUTI','P','10343','7.8',''),(401,'MENTARI PUSPITORENI','p','10445','7.2',''),(402,'QIANNA ARIDHANETTA','P','10300','7.1',''),(403,'NAZIRAH FADILLAH ITZEL','P','10326','7.7',''),(404,'KHANSA AISYAH RUBY','P','10255','7.1',''),(405,'KENZIE NARARYA RADHIKA','l','10552','7.1',''),(406,'YUFARA HAMAI AZZARA','p','10571','7.3',''),(407,'MUHAMMAD SEPTIAN IRSYAD','L','10355','7.5',''),(408,'NICHOLAS ADRIAN MEHAN GINTING','L','10261','7.9',''),(409,'MUHAMMAD DANADIPA AKMAL','l','10428','7.3',''),(410,'ZEVA ABIDUN NAFIS','l','10569','7.9',''),(411,'GHALIN ILYAS MU\'TASHAM','L','10374','7.1',''),(412,'MOCHAMAD NIZAM ZULFIKAR','l','10420','7.4',''),(413,'LUTHFI SAKHI AVIANDI','L','10360','7.9',''),(414,'SAUSAN AMIRA NAZHIFA','P','10313','7.4',''),(415,'GHANI ILMI RIZKI','l','10421','7.5',''),(416,'NAZWA YUJISTA','P','10292','',''),(417,'QIANDRA CLARISSALODIE RAHARDJO','P','10272','7.9',''),(418,'MOHAMAD TAZA JAVIER','l','10508','7.2',''),(419,'ALTHAF YASYKUR','l','10564','7.6',''),(420,'HIBRA AKBAR WILDANA','l','10417','7.1',''),(421,'KHAFI DIANSYAH','l','10470','7.9',''),(422,'FARAS RAMADHANU','l','10441','7.7',''),(423,'NADYA PUTRI DINATA','p','10440','7.6',''),(424,'MUHAMMAD NUFAIL AL FATIH','l','10407','7.7',''),(425,'LIDYA PUTRI DINATA','p','10439','7.5',''),(426,'ADINDA MAHARANI','P','9697','9.8',''),(427,'ALIF FAJAR RAMADHAN','L','9699','9.4',''),(428,'BINTANG ARYASATYA APRILIANTINO','L','9704','9.1',''),(429,'CALISTA OIEYVINA NUGROHO','P','9705','9.1',''),(430,'EVRYELLA ALZENNA DEWI SYAHMITA','P','9708','9.6',''),(431,'GENDIS ALYSIA DARAJAT','P','9710','9.5',''),(432,'HARUM AZHAAR','P','9711','9.6',''),(433,'IRGHI YUAN RAMDHANI','L','9713','9.6',''),(434,'KEYRIANA VINO AISYAHRANI','P','9715','9.4',''),(435,'MUHAMMAD RIZKY HAWALLI','L','9721','9.5',''),(436,'QALESYA AZKA NADINE','P','9723','9.7',''),(437,'RACHEL CORRY RAMADHANI','P','9724','9.2',''),(438,'RADIT SHEMDINATA','L','9725','9.6',''),(439,'SHERYL NURYADI','P','9730','9.7',''),(440,'AIRIL JOHARI','L','9733','9.3',''),(441,'ANNISA NUR AULIYA','P','9735','9.1',''),(442,'ASRUL SANI AL GHIFARI','L','9737','9.4',''),(443,'AURELLIA PUTRI HABSARI','P','9738','9.6',''),(444,'FAIZ ADNAN FAUZI','L','9742','9.5',''),(445,'FAUZAN','L','9746','9.1',''),(446,'IRDINA NAURAH PUTRI','P','9751','9.3',''),(447,'KAYLA NUR TREE OKTAVIANI','P','9753','9.4',''),(448,'MUHAMMAD AZRIL ILHAM','L','9756','9.7',''),(449,'NAKULA MARNUSYANTO','L','9758','9.4',''),(450,'SACHA AULIA ARIASTITA','P','9762','9.8',''),(451,'TAUHIDA IMROAN SHOLIHA ZULFATAHIYA','L','9765','9.7',''),(452,'ABDUL JALIL HAIDAR ALI','L','9767','9.7',''),(453,'ESHAN ALTHAF SYABIL','L','9779','9.3',''),(454,'FAIQ ATHAYA','L','9780','9.6',''),(455,'FAIZ DHIA ZHAFAR','L','9781','9.1',''),(456,'KENDRA ALIKHA RAMADHANI','P','9784','9.4',''),(457,'MOHAMMAD KENZIE PRAYATA','L','9787','9.5',''),(458,'MUHAMMAD QAISER NASHWAN','L','9790','9.2',''),(459,'OVI SILVANA','P','9795','9.6',''),(460,'SASKIA ANANDITA PRATIWI','P','9799','9.7',''),(461,'AHMAD ZULFIKAR FADHLY','L','9803','9.1',''),(462,'ANDITA PUTRIE MAULINDA','P','9806','9.2',''),(463,'ANGGITA APRIYANTI','P','9808','9.1',''),(464,'ARIF KURNIA ATMAJA','L','9809','9.4',''),(465,'ARUNI FALAKHA TRI MUMPUNI','P','9811','9.1',''),(466,'CARISSA NAOMI TAMPUBOLON','P','9813','9.4',''),(467,'FAHRY ANUGRAH KUSUMA','L','9817','9.2',''),(468,'ILHAM WIJAYA','L','9818','9.2',''),(469,'JUWITA PUSPITASARI','P','9819','9.5',''),(470,'MUHAMMAD FAHMI AL FIQIH','L','9823','9.6',''),(471,'NABILA HILFI ANANDA','P','9825','9.6',''),(472,'NASHITA LAILY ZAHIRA','P','9826','9.8',''),(473,'RIZKY MULYA PRATAMA','L','9832','9.6',''),(474,'SEPTA RAFKY ALWARITSU','L','9833','9.3',''),(475,'ZIVARA NUWALA PUTRI','P','9837','9.7',''),(476,'ALYSA CLAUDIA KUSUMA','P','9839','9.2',''),(477,'FAKHRI AKMA FADHIL','L','9845','9.5',''),(478,'FATHIR ADHI SYAPUTRA','L','9846','9.7',''),(479,'KALISTA QONITA PUTRI','P','9851','9.2',''),(480,'KHOIRUL IRSYAD','L','9853','9.2',''),(481,'MUHAMMAD AZHAR FADILLAH','L','9857','9.2',''),(482,'NADZWA APRILLYA','P','9859','9.7',''),(483,'RADITYA KEYZAN SYAMPUTRA','L','9862','9.5',''),(484,'RASYA KEANU ALBARI SYAM','L','9866','9.8',''),(485,'RESKIKA NUR OKTAVIANI','P','9867','9.3',''),(486,'SADEWA MARNUSYANTO','L','9868','9.7',''),(487,'AHMAD FADLI','L','9873','9.4',''),(488,'ALETA CHIKA NUGRAHA','P','9875','9.6',''),(489,'AUDIS FEBRIANTI','P','9876','9.6',''),(490,'AZIZAH SETIAWAN','P','9877','9.3',''),(491,'DWI HANDIKA','L','9880','9.1',''),(492,'FATHAN FADHILAH','L','9882','9.1',''),(493,'JERRICO JEFA ALIF SETYAWAN','L','9885','9.1',''),(494,'KAIA SIBYL HABIBAH','P','9886','9.3',''),(495,'MAURA KHAIRUN NISA','P','9888','9.7',''),(496,'MUHAMAD ABDUL LATIF','L','9891','9.3',''),(497,'MUHAMAD BIMA SAKTI RANGGA PUTRA AJI','L','9892','9.1',''),(498,'MUHAMMAD FADILLAH JAILANI','L','9893','9.5',''),(499,'MUHAMMAD RIZKY','L','9894','9.3',''),(500,'RADHITYA PUTRA PERMANA','L','9895','9.3',''),(501,'REYFHAN TRISNA NOERADHITYA','L','9899','9.6',''),(502,'ACHMAD FADLU RAHMAN','L','9907','9.2',''),(503,'ADITYA BINTANG PRATAMA','L','9908','9.1',''),(504,'DENNIAR FARDIAN WICAHYA SYAHPUTRA','L','9911','9.8',''),(505,'DIAN PUTRI PERMATASARI','P','9914','9.7',''),(506,'FAHREZA ADAM CRISTIANTOMY','L','9915','9.3',''),(507,'FAIRUZ PUTRI KHIRANIA','P','9916','9.2',''),(508,'JESSYCA BELIA PUTRI','P','9919','9.7',''),(509,'KANDIKA','L','9922','9.7',''),(510,'KASIH MAGDALENA','P','9923','9.7',''),(511,'KAYLA RINJANI AZZAHRA','P','9924','9.3',''),(512,'LEGITHA AVRILLIA MAHARANI','P','9925','9.7',''),(513,'MEISYA LONA PLARASUKA','P','9927','9.1',''),(514,'MUTIARA FATHINAH NUR IMAN','P','9930','9.3',''),(515,'NADIN SYAFIRA','P','9931','9.4',''),(516,'NOVIANA EKA RAHAYU','P','9933','9.2',''),(517,'QUEENSHA AULIA SYIFA','P','9934','9.3',''),(518,'RIVANO SATRIO NUGROHO','L','9935','9.5',''),(519,'SATRIO ARIF ATHAYA','L','9936','9.7',''),(520,'VERA APRILIANI','P','9939','9.6',''),(521,'ANGEL COSTARYCA PURBA','P','9944','9.7',''),(522,'CHAYARA EMBUN NARACHITA','P','9950','9.5',''),(523,'DAFFA AGUNG PRAMUDYA','L','9951','9.1',''),(524,'RAFA RONALDI','L','9968','9.5',''),(525,'RENO INDRAYANA','L','9971','9.3',''),(526,'SAMUEL DAPEACE','L','9973','9.7',''),(527,'HARI WISTORO BANGUN','L','9988','9.4',''),(528,'HILDA NOFRIDA','P','9990','9.6',''),(529,'ALYA  NURHADISTY','P','9997','8.2','9997.jpg'),(530,'ALZEMA HARUM RAMADHAN','L','9998','8.2','9998.jpg'),(531,'ANDINI ARUNINGTYAS','P','9999','8.4','9999.jpg'),(532,'ZAHWA ANINDITA FAUZI','P','10384','',''),(533,'FAISAL AL RIZKI','l','10516','',''),(534,'QAISYI RAFA SAVARAZ','l','10556','',''),(535,'DYHAN OKAVIANO','l','10108','7.7',''),(536,'Muhammad Sultan Haydir Ali','l','10116','7.2',''),(537,'Hasanudin','l','95555','',''),(538,'ADAM KANA BAWI','L','9992','',''),(539,'ADERA LUQYANA KHALDA','P','9993','8.2',''),(540,'AIRA SA\'BANIYAH','P','9994','8.1','9994.jpg'),(541,'AISHA AINUN MAHYA','P','9995','8.4','9995.jpg'),(542,'ALFIAN PURNOMO SIDIK','L','9996','','9996.jpg'),(543,'DHIYA FITRI SALSABILA ZAINIS','P','10005','8.5','10005.jpg'),(544,'GALIH RAMDANI','L','10007','','10007.jpg'),(545,'GHINA NUR ALAYYA','P','10008','8.7','10008.jpg'),(546,'KANAYA LUTFHI SHALSYA BILA','P','10009','','10009.jpg'),(547,'KHAIRANI LATIFAH AINI','P','10010','8.2','10010.jpg'),(548,'MUHAMAD ZULKARNAIN','L','10013','','10013.jpg'),(549,'MUHAMMAD FAIZ HABIBI','L','10014','','10014.jpg'),(550,'MUHAMMAD FARIQ AKHDAN','L','10015','','10015.jpg'),(551,'MUHAMMAD LUTHFI ZAIDAN','L','10017','8.5','10017.jpg'),(552,'MUHAMMAD RAYN AL NADIM','L','10247','',''),(553,'MUHAMMAD RIFAN MAULANA','L','10018','','10018.jpg'),(554,'MUHAMMAD ZEIN ALDIANSYAH','L','10020','','10020.jpg'),(555,'NAUFAL HABIBI','L','10023','8.7','10023.jpg'),(556,'NAYARA KIRANA ADIRAHAYU','P','10024','','10024.jpg'),(557,'PATIH PUTRA DESTIAN','L','10025','8.1','10025.jpg'),(558,'AHMAD HUSEIN','L','10029','8.6',''),(559,'ARFA RAFI AZKHA PUTRA JAWAK','L','10033','',''),(560,'AURELIA ANGGRAENI','P','10034','8.7',''),(561,'FAAIQ AL AZZAAM','L','10035','8.1',''),(562,'FADIL RIYADI AL HAJJ','L','10036','8.4',''),(563,'FAJAR MANUNGGALING FADILLAH','L','10037','',''),(564,'FARZAN AHZA ARGANI','L','10038','8.2',''),(565,'FERNANDA MUTIA KASIH','P','10039','',''),(566,'GHASAWAN RAUSAN FIKRI','L','10040','8.2',''),(567,'INDRA AKBAR MUHROBI','L','10041','8.3',''),(568,'JANEETA DHIA SYARAFANA FERDHA','P','10042','8.3',''),(569,'LOVELY ZAAHIRA VIOLETHA','P','10044','8.5',''),(570,'M RAFFA KURNIAWAN','L','10249','',''),(571,'MUHAMMAD NASUHA PRASETYA','L','10045','8.4',''),(572,'MUHAMMAD NAUFAL SYAFIQ','L','10046','',''),(573,'MUHAMMAD RASYA FADILLAH','L','10047','',''),(574,'MUHAMMAD RIDHO','L','10048','',''),(575,'MUTIARA RENGGANIS KURNIAWAN ROY','P','10050','8.2',''),(576,'NAELATUR ROJA','P','10052','',''),(577,'QOTRUNNADA','P','10053','',''),(578,'RIFQI ABDILLAH PRAYITNO','L','10058','',''),(579,'STEPHANNY FREDERICA','P','10059','',''),(580,'ZAHRAN RAMADHAN','L','10062','',''),(581,'ABUZAR','L','10063','',''),(582,'ALVIS GAVRILA SIREGAR','L','10068','8.1',''),(583,'ARKAN FATURRACHMAN','L','10071','',''),(584,'FAKHRI HIBATULLOH','L','10075','',''),(585,'HIROSHI MARSIMA','L','10078','',''),(586,'KENZIE PASHA SEPTIANZA','L','10079','8.5',''),(587,'MUHAMAD BILAL ALFIAN MAHMUD','L','10081','8.3',''),(588,'MUHAMMAD DAFVIAN ALVATAR','L','10082','',''),(589,'MUHAMMAD NEVAN SAVAPUTRA. M','L','10084','',''),(590,'NABILA UMMUHANI','P','10087','',''),(591,'NISA LATI MUSLIMAH','P','10088','8.3',''),(592,'QATRINNADA KHALISA','P','10089','',''),(593,'RAHMAT DERMAWAN','L','10091','',''),(594,'SABRINA NOVIANTI','P','10092','',''),(595,'WINOLA DWI PRASETYA','P','10094','8.4',''),(596,'ZAHIRA SAFITRI','P','10095','',''),(597,'ZIVARA RIZKA ALTHAFUNISSA','P','10097','',''),(598,'AHMAD FAUZHI','L','10098','8.3',''),(599,'ALENA CHELSEA APRILYAN','P','10099','',''),(600,'ALVI DAMAYANTY','P','10100','',''),(601,'AZKA IBNU FIQI','L','10103','',''),(602,'BAIHAKI ULHAQ KAIZAN','L','10105','8.3',''),(603,'CITRA SANIA','P','10106','8.4',''),(604,'DAANISH GULWANI FAIZ','L','10107','8.3',''),(605,'GALANG CAKRA GUNAWAN','L','10110','8.1',''),(606,'IBRAHIM RIZKI AIDIL AKBAR','L','10111','',''),(607,'KANAYA APRILIA','P','10112','',''),(608,'MOHAMMAD FABIAN ALVARO','L','10113','',''),(609,'MUHAMAD HAMZAH MAULANA','L','10115','',''),(610,'MUHAMMAD ANUGRAH ALFAREZY','L','10114','',''),(611,'RAFA NUHA NAZWA','L','10121','',''),(612,'RAIHANNA DZAHIRA','P','10122','8.7',''),(613,'RAKHA ADITYA RASHIF','L','10123','8.5',''),(614,'REAYLITA NUR AZHARA','P','10124','',''),(615,'RESTU ADITIYA ANDHANI','L','10125','',''),(616,'REZKY NAZRIL ILHAM','L','10126','8.2',''),(617,'ROSNAULI HARAHAP','P','10128','',''),(618,'SAMSUL IMAM GUNAWAN','L','10130','',''),(619,'TIFFANY AURELIA','P','10131','',''),(620,'ADINDA PUTRI ASTUTI','P','10133','8.2',''),(621,'AGUNG AGUSTIAN MAULANA ADIYANSA','L','10134','',''),(622,'ALYAA RINJANI','P','10136','',''),(623,'AQUINNA GHANIA WICAKSONO','P','10137','',''),(624,'CHAERUL SUGIARTO','L','10140','8.6',''),(625,'FEBRYANA PUTRI AQILAH','P','10144','8.1',''),(626,'HAFIFAH ANDINY NUR MAYLA','P','10147','',''),(627,'KANAYA PUTRI RAMDANI','P','10149','8.3',''),(628,'KEYSHA TRI MULYANI','P','10150','',''),(629,'LONA AZHIMU','P','10151','8.1',''),(630,'MUHAMMAD ALTHAF NUR ADIA','L','10153','',''),(631,'MUHAMMAD DATUL KAHFI RASIDIN','L','10154','',''),(632,'MUHAMMAD FADLI AKMAL','L','10155','8.4',''),(633,'MUHAMMAD RIOS HAIRIYAWAN','L','10157','8.7',''),(634,'MUHAMMAD ZIHNI KAROMI','L','10158','',''),(635,'NATHANIA NUR AFIIFAH HARTONO','P','10159','8.2',''),(636,'NUR AZIZAH GULTOM','P','10160','8.5',''),(637,'RINA PUTRIANA','P','10164','8.3',''),(638,'SATRIA TAMA RAMADHAN','L','10165','',''),(639,'SITI FADILLAH','P','10166','8.5',''),(640,'ADINDA KHAIRUNISA','P','10169','',''),(641,'AKILA ANINDITA','P','10170','8.1',''),(642,'ARTHUR JONATHAN PASARIBU','L','10172','',''),(643,'AZRIL AFRIZAL','L','10173','',''),(644,'DINAH SETYA HUSNA','P','10177','8.2',''),(645,'GRISELDA AILSA SEBAYANG','P','10180','',''),(646,'HANIF AL ADLUL LATIEF','L','10181','',''),(647,'JEREMIA BARITA TULUS SIHOTANG','L','10182','',''),(648,'LALU RIZKY ZAIDAN','L','10185','8.4',''),(649,'LISA APRILLIA MUSLIMAH','P','10186','8.4',''),(650,'MEISYA MAHARANI','P','10187','8.5',''),(651,'MUHAMMAD BIMA AZHAR','L','10190','8.7',''),(652,'MUHAMMAD FARHAN ARDIANSYAH','L','10251','',''),(653,'MUHAMMAD RAFIQ ABDULLAH','L','10192','',''),(654,'MUHAMMAD RIZQI AZZAHQRI','L','10194','8.5',''),(655,'NISYA SYAM PUTRI','P','10197','',''),(656,'RIDWAN FADIL RAHMAN','L','10200','',''),(657,'ROSA OKI SAGITA','P','10201','8.1',''),(658,'ACHMAD ALFARREL QINTHARU','L','10204','8.1',''),(659,'AILSA HUMAIRA MAHARANI','P','10205','8.2',''),(660,'AULIA DESCA AFIFAH','P','10209','',''),(661,'AZZAHRA NUR ASSYIFA','P','10210','8.2',''),(662,'CHRISTOPHER NATHANIEL BALA KELEN','L','10211','8.6',''),(663,'DAENG ASLAH NABAWIE','L','10213','',''),(664,'FARHAN NABIL ALBUKHORI','L','10214','',''),(665,'FATTAH LABIB SIDIQ','L','10215','8.1',''),(666,'HANIFA KAREZMAWATI','P','10217','',''),(667,'HUGO APRILIANO','L','10218','',''),(668,'IMADA LUCAS MANGARAJA DOLOK SARIBU','L','10219','',''),(669,'IVANA DIAS MARISA','P','10220','8.7',''),(670,'KHANSA SHAKILA ALLYANA','P','10223','8.4',''),(671,'LIVIA SISTA DELVARA','P','10224','',''),(672,'LUCIO BENEDIKTO ALDO KEBE','L','10225','',''),(673,'MUHAMMAD ABU BAKAR','L','10227','',''),(674,'MUHAMMAD AKBAR DERMAWAN','L','10228','',''),(675,'MUHAMMAD RAKHA ASSYRAF','L','10230','',''),(676,'MUHAMMAD RASYA ARIYA','L','10231','8.5',''),(677,'NADYA SARADIVA SYAH','P','10232','',''),(678,'PEDRO TOMPI BOREZ HUTASOIT','L','10234','',''),(679,'RAINA AYU SAPUTRI','P','10237','8.7',''),(680,'WELLY AL-QORNI','L','10238','',''),(681,'ADITYA CAHAYA PURNAMA PUTRA','L','9802','9.8',''),(682,'ADRIAN EL NINO','L','9698','',''),(683,'ANINDITYA MEYCA RAIFA','P','9770','9.1',''),(684,'CHALISAH PUTRI','P','9949','',''),(685,'DENNISH EZRA MAHARDIKA','L','9912','',''),(686,'DINDA ZAZKIA DEWI','P','9952','',''),(687,'FAIZ FIRDAUS','L','9917','',''),(688,'KAFI ZUFAR RADINKA','L','9752','9.6',''),(689,'MOHAMMAD RIZQI JUANDA','L','9754','9.6',''),(690,'NINA RISANTI','P','9966','9.5',''),(691,'QUINA ANINDYA DEWI','P','9796','',''),(692,'RAFFY APRIANSYAH','L','9864','9.7',''),(693,'RAHENDRA ARIOBARRA','L','9797','',''),(694,'SAUZAN SYARIFA','P','9902','',''),(695,'SIGIT HERMAWAN','L','9800','',''),(696,'AISYAH AJENG AYU MAHARANI','P','9804','',''),(697,'ALIYA NAILATUN NAJWA','P','9805','',''),(698,'ANTAREJA BANYU MAHESWARA','L','9946','',''),(699,'ARKAN NURANDI TAJRIANSYAH','L','9989','',''),(700,'BANYU REZZKA ALVINO','L','9739','',''),(701,'BAYU AGUNG NUGROHO','L','9947','',''),(702,'CAHYA AURELIA SEPTA','P','9740','',''),(703,'DZAKIYAH HAFIFATUNNISA','P','9815','',''),(704,'EPELLIA FHITRI','P','9741','',''),(705,'FIONA ALYA SAPUTRI','P','9848','',''),(706,'GALANG SETIAWAN','L','9918','',''),(707,'IDAM NURIL MUKHORIM','L','9712','',''),(708,'INDHIRA EVRILIA','P','9884','9.6',''),(709,'IZZAT GILANG CANDRIKA','L','9714','',''),(710,'MAULANA MUHAMAD YUSUP','L','9961','',''),(711,'MUHAMMAD AZZAM DAULI','L','9987','',''),(712,'MUHAMMAD RIZKY AQWIYAH','L','9964','9.4',''),(713,'NAIA RIZKA SILVIA','P','9792','9.4',''),(714,'NURJIHA SABRINA GHAISANI','P','9793','',''),(715,'RAFA AZAM ALFIYAN','L','9726','9.3',''),(716,'RANGGA FAIZ','L','9865','',''),(717,'SYARIFAH ANDHINI HAYOTO','P','9801','9.1',''),(718,'TANIA APRILIA','P','9834','9.1',''),(719,'ABDULLAH IBNU BATUTA','L','9696','',''),(720,'AKHDAN BHADRIKA','L','9874','',''),(721,'ALKISYAH REWAE','P','9734','',''),(722,'ANDRY TRIANA HIDAYAT DENY SAPUTRA','L','9807','',''),(723,'ARGHYA RAVA AGISTA','L','9772','',''),(724,'ATIKA PUTRI RAHAYU','P','9773','9.3',''),(725,'AUFA FAUZAN RIALDI','L','9841','',''),(726,'DELLA SYAHRANI','P','9706','9.4',''),(727,'DEVIN AQILA RAFASYAH','L','9913','',''),(728,'MUHAMMAD ANANDA SADIXTA','L','9856','',''),(729,'MUHAMMAD FHADIL','L','9789','',''),(730,'MUHAMMAD MARFEL ALFIANDINOVA','L','9858','9.4',''),(731,'NABILA NUR KHOLIFAH','P','9757','',''),(732,'NURFI SYABILLA','P','9759','9.6',''),(733,'QUAIS ALQORNI','L','9828','',''),(734,'RAISA BALQIS AZZAHRA','P','9727','9.5',''),(735,'RENITA SAFITRI','P','10253','',''),(736,'SYAHWANDA MERBY AZALLA','P','9905','',''),(737,'TIKA CAHAYA NURHIKMAH','P','9937','',''),(738,'TRI MAULIDA HENDRI PUTRI','P','9870','9.8',''),(739,'ZIDNI ROHADATUL \'AISY','P','9906','',''),(740,'ARAMI KUKUH MANGGALA PUTRA','L','9771','9.5',''),(741,'BARAKA DWI GHANIYYU','L','9775','9.3',''),(742,'CHAESAR CLEO AL FARIZH','L','9948','',''),(743,'DERIF HAFIDZ RIZKY','L','9878','',''),(744,'DITA APRIYANA','P','9879','9.6',''),(745,'FAHRI DJAINUDIN','L','9953','',''),(746,'FATIMAH AZZAHRA','P','9847','',''),(747,'FIRDA FARIZA GUNAWAN','P','9709','',''),(748,'HAIDIL KHADAFI','L','9749','',''),(749,'HANA OCTAVIA KHAIRUNNISA','P','9750','9.8',''),(750,'KYLA AULIA PRASETYO','P','9786','9.1',''),(751,'MUHAMMAD AMMAR FADHLY','L','9855','9.1',''),(752,'MUHAMMAD FATHAN AL FALAH','L','9788','',''),(753,'RAYFAN RAMADHAN','L','9830','',''),(754,'REYHAN DIMITREE MAHENDRY','L','9728','9.3',''),(755,'RISYIFA ROSICKY','P','9761','9.4',''),(756,'SHABILA ANGGRAENI','P','9903','9.6',''),(757,'SHAFA FADILLAH GAJA','P','9763','9.3',''),(758,'SIFA FAUZIAH','P','9904','9.1',''),(759,'SYARAH MAULIDA','P','9764','9.3',''),(760,'AGVA SHADDAM ALI','L','9769','9.6',''),(761,'AHMAD IBRAHIMOVIC','L','9838','9.3',''),(762,'AMANDA NUR AZIJAH','P','9840','9.4',''),(763,'AMZHAR SYAUQI OKKA YULIANSYAH','L','9942','9.1',''),(764,'BISHRIL MA\'ARIF','L','9844','',''),(765,'DION LAZUARDI PUTRA','L','9707','9.8',''),(766,'FAIZAL LUTFI AL FATAH','L','9881','',''),(767,'FAKHIRA NADHEFA ALTHAFUNNISA','P','9743','',''),(768,'IZQIEVIDIANA','P','9957','',''),(769,'KAYLA KHAIRINA RASYID','P','9958','',''),(770,'KEISYA FATHIYYAH ADRIANI','P','9991','',''),(771,'MOCHAMMAD ERFINO HIDAYAT','L','9962','',''),(772,'MUHAMAD FADLI FEBRIANTO','L','9963','',''),(773,'MUHAMMAD AZKA KUMARA ADI','L','9929','9.5',''),(774,'NENO MEIRANI','P','9932','',''),(775,'OKATARA RAFAEL ARFAN','L','9827','',''),(776,'RAFA ARDIANSYAH','L','9967','9.6',''),(777,'TANAYA TAMA NUNGKA FALAQI MOJAWI','L','9974','9.8',''),(778,'YUDA RASHA RANATA','L','9835','9.7',''),(779,'YULIANA','P','9836','9.8',''),(780,'ZAIDAN ARBHIE FADILLAH','L','9977','9.3',''),(781,'AHMAD HAFIDZ ANNAZILY','L','9732','',''),(782,'ALLYA AIRRAH SYAFA','P','9909','',''),(783,'ARINA FAIZA NURADITYA','P','9736','9.5',''),(784,'AZKA NURSALSA','P','9774','9.2',''),(785,'AZZA SYAHARA PUTRI','P','9842','9.2',''),(786,'BERLENS RAFEL WILLYANSYAH','L','9910','',''),(787,'DARMA UMAR THALIB','L','9776','',''),(788,'DAVA NOVIANSYAH','L','9777','',''),(789,'ENGGAR HARYO ADIWENO AFANDI','L','9778','',''),(790,'KEYSYA KANZA DEPITA','P','9820','9.4',''),(791,'M. FAHRI','L','9717','9.4',''),(792,'MAHAR AKRAM KHADAFI','L','9821','9.4',''),(793,'MEISY RAYYA PUTRI','P','9716','',''),(794,'MUHAMAD IHSAN','L','9822','9.5',''),(795,'MUHAMAD PRABU RAMADHAN','L','9718','',''),(796,'MUHAMAD TAMIM ALGOZALI','L','9854','',''),(797,'MUHAMMAD AZRIEL PUTRA SANTOSO','L','9755','9.5',''),(798,'NAJMA SHAFA LAILA','P','9965','9.3',''),(799,'NASYA INDIRA PUTRI','P','9860','',''),(800,'NURUL FITRI SEPTIA','P','9794','',''),(801,'PUTRI ANGGRAINI','P','9722','',''),(802,'RAFFA MAULANA ADHA','L','9896','',''),(803,'RAMADHANI RUSMIN','L','9760','',''),(804,'RIZKY ADITHYA ANUGRAH','L','9900','',''),(805,'RIZKY ADITIYA','L','9798','9.7',''),(806,'SABRINA','P','9901','9.5',''),(807,'SALSHABILA AZZAHRA','P','9972','',''),(808,'ZALVIN DAHLIAN MAHADANI SITUMORANG','L','9766','',''),(809,'ADILLA MEILANI PUTRI','P','9872','',''),(810,'ANABELLA YUKI AURELIA','P','9943','',''),(811,'ANISA PUTRI AGUSTIANTY','P','9700','',''),(812,'AQILLAH NASHITA DWI ARIFIANTI','P','9701','',''),(813,'ELVIRA SHAFA NAWAVILLA','P','9816','',''),(814,'FAKHRI UKAIL SANTOSA','L','9744','',''),(815,'FARIZ ARDIANSYAH','L','9745','',''),(816,'FELLICIA AIRA MALEEKHA','P','9883','',''),(817,'GILBERT LUMAINDONG NABABAN','L','9955','',''),(818,'GLADYS IVANNA HUTAPEA','P','9956','',''),(819,'HAICEL SEPTIAWAN ABIDIN','L','9782','',''),(820,'HAURA ARDINI','P','9783','9.2',''),(821,'KEYZAN DIRA PRATAMA','L','9887','9.2',''),(822,'MANUELLA KARYN ROSINAULI','P','9926','',''),(823,'MIECHELL ZANETHA SIAHAAN','P','9928','',''),(824,'MOHAMMAD NAUVAL AZ-ZIKRA','L','9890','',''),(825,'MUHAMMAD KEISA FEBRIANSYAH MALIK','L','9720','9.1',''),(826,'NURUL FAUZIAH','P','9861','9.4',''),(827,'RAFA HAFIIZI ABIMANYU','L','9863','9.2',''),(828,'RAYHAN RAFA AKBAR','L','9970','',''),(829,'SABRINA NAYSA WAHAB','P','9729','',''),(830,'SARVINA MAHDA WATTIHELU','P','9869','',''),(831,'VINCENTIUS KRISNA PUTRA','L','9976','',''),(832,'VIONA CITRA SITORUS','P','9940','',''),(833,'YOSEF HAYON HALA NIRON','L','9941','',''),(834,'ANGRENI EVALINA SITOMPUL','P','9945','',''),(835,'AZRIEL FEBRI AKBAR','L','9702','',''),(836,'AZZAM BAGUS SYANDANA','L','9812','',''),(837,'BAGAS PRATAMA','L','9703','9.3',''),(838,'FERDINAND ARYA RIHI MONE','L','9954','9.7',''),(839,'GALANK RAKHA FIRMANSYAH','L','9747','',''),(840,'GOFUR ALFAYET NUGROHO','L','9748','',''),(841,'HESKIANO RAFAEL HUTAGAOL','L','9633','',''),(842,'IRLAND','L','9849','',''),(843,'JOAN ABNER MATTHEWTUA TAMBUNAN','L','9920','',''),(844,'JUAN GERRALD MULYANA','L','9921','9.8',''),(845,'KEISHA KAFKA NAFIZA','P','9852','',''),(846,'KIANDRA RALLY MOHUNE','L','9785','',''),(847,'MARIA DWI TRESIA SINURAT','P','9960','',''),(848,'MUHAMMAD RADHY ALKHALIFFI KURNIAWAN','L','9824','',''),(849,'NADIN QUROTA AINI MAHENDRA','P','9791','9.3',''),(850,'RANGGA PRAKASSA PUTRA CHRISTIAN LENGKONG','L','9969','',''),(851,'RASYA AL RAHMAN','L','9897','9.7',''),(852,'REINA DHIZA ETRI KAYLA','P','9898','',''),(853,'TRI AYAMEWATI','P','9975','9.5',''),(854,'VANESA SEPTYASA NURMIATI','P','9871','',''),(855,'MICHAEL ESTU RAHMAD SAMUDRA','L','10577','',''),(856,'MUHAMMAD RIDHO KURNIA','L','10578','',''),(857,'RAISSA ZANETHA SYAWALI','P','10580','',''),(858,'MUCHAMAD ILHAM FEBRIANSYAH','L','10581','',''),(859,'NADIFAH SALSABILAH','P','10583','',''),(860,'ANDIKA DWI PUTRA','L','10584','',''),(861,'ERICK TIMOTHY SARAGIH','L','10588','','');
/*!40000 ALTER TABLE `siswa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tapel`
--

DROP TABLE IF EXISTS `tapel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tapel` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tapel` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `smt` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tahun` varchar(5) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `aktif` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tapel`
--

LOCK TABLES `tapel` WRITE;
/*!40000 ALTER TABLE `tapel` DISABLE KEYS */;
INSERT INTO `tapel` VALUES (2,'2025/2026','2','2026','0'),(3,'2025/2026','1','2025','0');
/*!40000 ALTER TABLE `tapel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_devices`
--

DROP TABLE IF EXISTS `user_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_devices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `device_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_devices`
--

LOCK TABLES `user_devices` WRITE;
/*!40000 ALTER TABLE `user_devices` DISABLE KEYS */;
INSERT INTO `user_devices` VALUES (1,'ME','e498e52563bcc263f0ce9b6170713d661a28d7d51d8f2b8c9966dd839b047f77','2026-01-24 16:56:20','2026-02-23 16:56:20'),(2,'ME','9e54460e08c7f0fd4794a6e972740e5912659f8d94f919ba1d1eafedfb8229bd','2026-01-25 23:56:47','2026-02-24 23:56:47'),(3,'ME','18876502bc5e83401e23ec736d1a9525a91d466ee53a859ba0d2106f1e920b2e','2026-01-26 07:37:36','2026-02-25 07:37:36');
/*!40000 ALTER TABLE `user_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usera`
--

DROP TABLE IF EXISTS `usera`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usera` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `nama` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `nik` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `poto` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `status` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '1',
  `ip` varchar(45) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `google_secret` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `email_code` varchar(6) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `email_code_expired` datetime NOT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `level` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '1',
  `idu` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usera`
--

LOCK TABLES `usera` WRITE;
/*!40000 ALTER TABLE `usera` DISABLE KEYS */;
INSERT INTO `usera` VALUES (1,'ME','$2y$10$85xlsiFhjur3/EbI.lRww.JT.ATwySER4bhjelR5Gg5mcMuOS/436','Muharrom Eka',NULL,'1020713','ME_1769190549.jpg','1','::1','IQRTE7N46TGLQLTR','','2026-01-20 04:27:19','2026-01-26 07:37:15','1','v22jbuuoj1ms0d2i9k0c'),(3,'225993','$2y$10$2RekRGvlYHM0odu8A1iFmumtgP/4DqdKD6Nm7db69JXzwG.6ZjmHi','FAJRIYANTO',NULL,'225993',NULL,'1','127.0.0.1',NULL,'','0000-00-00 00:00:00','2026-01-25 04:33:14','2','9ok9itvmpcavjkq9a6lv');
/*!40000 ALTER TABLE `usera` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usera_log`
--

DROP TABLE IF EXISTS `usera_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usera_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `nama` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `waktu` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `ip` varchar(25) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `info` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usera_log`
--

LOCK TABLES `usera_log` WRITE;
/*!40000 ALTER TABLE `usera_log` DISABLE KEYS */;
INSERT INTO `usera_log` VALUES (1,'ME','Muharrom Eka','2026-01-25 05:21:38','127.0.0.1','Login'),(2,'ME','Muharrom Eka','2026-01-25 22:11:45','127.0.0.1','Login'),(3,'ME','Muharrom Eka','2026-01-25 23:56:47','192.168.1.83','Login'),(4,'ME','Muharrom Eka','2026-01-25 23:57:51','192.168.1.83','Login'),(5,'ME','Muharrom Eka','2026-01-26 00:49:56','192.168.1.83','Menghapus Data Prestasi Atas Nama: ABDUR WAFI ALI'),(6,'ME','Muharrom Eka','2026-01-26 02:20:00','127.0.0.1','Login'),(7,'ME','Muharrom Eka','2026-01-26 07:37:36','127.0.0.1','Login'),(8,'ME','Muharrom Eka','2026-01-26 10:50:56','127.0.0.1','Menambah Data Prestasi Atas Nama: ABDUL JALIL HAIDAR ALI'),(9,'ME','Muharrom Eka','2026-01-26 10:52:30','127.0.0.1','Menambah Data Prestasi Atas Nama: ABDUR WAFI ALI'),(10,'ME','Muharrom Eka','2026-01-26 10:53:30','127.0.0.1','Menghapus Data Prestasi Atas Nama: ABDUL JALIL HAIDAR ALI'),(11,'ME','Muharrom Eka','2026-01-26 10:54:03','127.0.0.1','Menghapus Data Prestasi Atas Nama: ABDUR WAFI ALI');
/*!40000 ALTER TABLE `usera_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usulan`
--

DROP TABLE IF EXISTS `usulan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usulan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_surat` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `judul` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tujuan` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tgl_dokumen` date DEFAULT NULL,
  `pdf` varchar(200) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usulan`
--

LOCK TABLES `usulan` WRITE;
/*!40000 ALTER TABLE `usulan` DISABLE KEYS */;
/*!40000 ALTER TABLE `usulan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `version`
--

DROP TABLE IF EXISTS `version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `version` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ver` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tgl` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `logupdate` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `ket` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version`
--

LOCK TABLES `version` WRITE;
/*!40000 ALTER TABLE `version` DISABLE KEYS */;
INSERT INTO `version` VALUES (1,'1.0.1','2026-01-02 01:58:54','0','0');
/*!40000 ALTER TABLE `version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'dnet_ad2025'
--

--
-- Dumping routines for database 'dnet_ad2025'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-26 15:19:05
